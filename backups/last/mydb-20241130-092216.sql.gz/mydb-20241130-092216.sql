--
-- PostgreSQL database dump
--

-- Dumped from database version 15.10
-- Dumped by pg_dump version 17.0 (Debian 17.0-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: AlertStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AlertStatus" AS ENUM (
    'INITIAL_INVESTIGATION',
    'ESCALATED',
    'RESOLVED'
);


ALTER TYPE public."AlertStatus" OWNER TO postgres;

--
-- Name: AlertType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AlertType" AS ENUM (
    'ALERT',
    'INCIDENT',
    'HARMLESS'
);


ALTER TYPE public."AlertType" OWNER TO postgres;

--
-- Name: AssetCriticality; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AssetCriticality" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'CRITICAL'
);


ALTER TYPE public."AssetCriticality" OWNER TO postgres;

--
-- Name: AssetType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AssetType" AS ENUM (
    'WINDOWS_WORKSTATION',
    'WINDOWS_SERVER',
    'LINUX_WORKSTATION',
    'LINUX_SERVER',
    'SERVER',
    'CONTAINER',
    'FIREWALL',
    'ROUTER',
    'DNS'
);


ALTER TYPE public."AssetType" OWNER TO postgres;

--
-- Name: AssetVisibility; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AssetVisibility" AS ENUM (
    'NONE',
    'ALERTS',
    'FULL'
);


ALTER TYPE public."AssetVisibility" OWNER TO postgres;

--
-- Name: DetectionSource; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DetectionSource" AS ENUM (
    'VELOCIRAPTOR',
    'WAZUH',
    'NATO',
    'OTHER'
);


ALTER TYPE public."DetectionSource" OWNER TO postgres;

--
-- Name: EventAction; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EventAction" AS ENUM (
    'INVESTIGATION',
    'KNOWLEDGE',
    'ACTION',
    'REPORTING'
);


ALTER TYPE public."EventAction" OWNER TO postgres;

--
-- Name: EventStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EventStatus" AS ENUM (
    'OKAY',
    'WARNING',
    'DOWN'
);


ALTER TYPE public."EventStatus" OWNER TO postgres;

--
-- Name: IOCType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."IOCType" AS ENUM (
    'MD5',
    'SHA1',
    'SHA256',
    'FILENAME',
    'PDB',
    'FILENAME_MD5',
    'FILENAME_SHA1',
    'FILENAME_SHA256',
    'IP_SRC',
    'IP_DST',
    'HOSTNAME',
    'DOMAIN',
    'DOMAIN_IP',
    'EMAIL',
    'EMAIL_SRC',
    'EPPN',
    'EMAIL_DST',
    'EMAIL_SUBJECT',
    'EMAIL_ATTACHMENT',
    'EMAIL_BODY',
    'FLOAT',
    'GIT_COMMIT_ID',
    'URL',
    'HTTP_METHOD',
    'USER_AGENT',
    'JA3_FINGERPRINT_MD5',
    'JARM_FINGERPRINT',
    'FAVICON_MMH3',
    'HASSH_MD5',
    'HASSH_SERVER_MD5',
    'REG_KEY',
    'REG_KEY_VALUE',
    'AS',
    'SNORT',
    'BRO',
    'ZEEK',
    'COMMUNITY_ID',
    'PATTERN_IN_FILE',
    'PATTERN_IN_TRAFFIC',
    'PATTERN_IN_MEMORY',
    'PATTERN_FILENAME',
    'PGP_PUBLIC_KEY',
    'PGP_PRIVATE_KEY',
    'YARA',
    'STIX2_PATTERN',
    'SIGMA',
    'GENE',
    'KUSTO_QUERY',
    'MIME_TYPE',
    'IDENTITY_CARD_NUMBER',
    'COOKIE',
    'VULNERABILITY',
    'CPE',
    'WEAKNESS',
    'ATTACHMENT',
    'MALWARE_SAMPLE',
    'LINK',
    'COMMENT',
    'TEXT',
    'HEX',
    'OTHER',
    'NAMED_PIPE',
    'MUTEX',
    'PROCESS_STATE',
    'TARGET_USER',
    'TARGET_EMAIL',
    'TARGET_MACHINE',
    'TARGET_ORG',
    'TARGET_LOCATION',
    'TARGET_EXTERNAL',
    'BTC',
    'DASH',
    'XMR',
    'IBAN',
    'BIC',
    'BANK_ACCOUNT_NR',
    'ABA_RTN',
    'BIN',
    'CC_NUMBER',
    'PRTN',
    'PHONE_NUMBER',
    'THREAT_ACTOR',
    'CAMPAIGN_NAME',
    'CAMPAIGN_ID',
    'MALWARE_TYPE',
    'URI',
    'AUTHENTIHASH',
    'VHASH',
    'SSDEEP',
    'IMPHASH',
    'TELFHASH',
    'PEHASH',
    'IMPFUZZY',
    'SHA224',
    'SHA384',
    'SHA512',
    'SHA512_224',
    'SHA512_256',
    'SHA3_224',
    'SHA3_256',
    'SHA3_384',
    'SHA3_512',
    'TLSH',
    'CDHASH',
    'FILENAME_AUTHENTIHASH',
    'FILENAME_VHASH',
    'FILENAME_SSDEEP',
    'FILENAME_IMPHASH',
    'FILENAME_IMPFUZZY',
    'FILENAME_PEHASH',
    'FILENAME_SHA224',
    'FILENAME_SHA384',
    'FILENAME_SHA512',
    'FILENAME_SHA512_224',
    'FILENAME_SHA512_256',
    'FILENAME_SHA3_224',
    'FILENAME_SHA3_256',
    'FILENAME_SHA3_384',
    'FILENAME_SHA3_512',
    'FILENAME_TLSH',
    'WINDOWS_SCHEDULED_TASK',
    'WINDOWS_SERVICE_NAME',
    'WINDOWS_SERVICE_DISPLAYNAME',
    'WHOIS_REGISTRANT_EMAIL',
    'WHOIS_REGISTRANT_PHONE',
    'WHOIS_REGISTRANT_NAME',
    'WHOIS_REGISTRANT_ORG',
    'WHOIS_REGISTRAR',
    'WHOIS_CREATION_DATE',
    'X509_FINGERPRINT_SHA1',
    'X509_FINGERPRINT_MD5',
    'X509_FINGERPRINT_SHA256',
    'DNS_SOA_EMAIL',
    'SIZE_IN_BYTES',
    'COUNTER',
    'DATETIME',
    'PORT',
    'IP_DST_PORT',
    'IP_SRC_PORT',
    'HOSTNAME_PORT',
    'MAC_ADDRESS',
    'MAC_EUI_64',
    'EMAIL_DST_DISPLAY_NAME',
    'EMAIL_SRC_DISPLAY_NAME',
    'EMAIL_HEADER',
    'EMAIL_REPLY_TO',
    'EMAIL_X_MAILER',
    'EMAIL_MIME_BOUNDARY',
    'EMAIL_THREAD_INDEX',
    'EMAIL_MESSAGE_ID',
    'GITHUB_USERNAME',
    'GITHUB_REPOSITORY',
    'GITHUB_ORGANISATION',
    'JABBER_ID',
    'TWITTER_ID',
    'DKIM',
    'FIRST_NAME',
    'MIDDLE_NAME',
    'LAST_NAME',
    'FULL_NAME',
    'DATE_OF_BIRTH',
    'PLACE_OF_BIRTH',
    'GENDER',
    'PASSPORT_NUMBER',
    'PASSPORT_COUNTRY',
    'PASSPORT_EXPIRATION',
    'REDRESS_NUMBER',
    'NATIONALITY',
    'VISA_NUMBER',
    'ISSUE_DATE_OF_THE_VISA',
    'PRIMARY_RESIDENCE',
    'COUNTRY_OF_RESIDENCE',
    'SPECIAL_SERVICE_REQUEST',
    'FREQUENT_FLYER_NUMBER',
    'TRAVEL_DETAILS',
    'PAYMENT_DETAILS',
    'PLACE_PORT_OF_ORIGINAL_EMBARKATION',
    'PLACE_PORT_OF_CLEARANCE',
    'PLACE_PORT_OF_ONWARD_FOREIGN_DESTINATION',
    'PASSENGER_NAME_RECORD_LOCATOR_NUMBER',
    'MOBILE_APPLICATION_ID',
    'CHROME_EXTENSION_ID',
    'CORTEX',
    'BOOLEAN',
    'ANONYMISED'
);


ALTER TYPE public."IOCType" OWNER TO postgres;

--
-- Name: NetworkColor; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NetworkColor" AS ENUM (
    'RED',
    'GREEN',
    'BLUE',
    'YELLOW',
    'PURPLE',
    'ORANGE',
    'PINK',
    'BROWN',
    'GRAY'
);


ALTER TYPE public."NetworkColor" OWNER TO postgres;

--
-- Name: ReportStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ReportStatus" AS ENUM (
    'NEW',
    'HAD_CHANGES',
    'REPORTED_NATIONAL',
    'REPORTED_INTERNATIONAL'
);


ALTER TYPE public."ReportStatus" OWNER TO postgres;

--
-- Name: ResponseActionStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ResponseActionStatus" AS ENUM (
    'OUTSTANDING',
    'APPROVED',
    'PENDING',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."ResponseActionStatus" OWNER TO postgres;

--
-- Name: ResponseActionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ResponseActionType" AS ENUM (
    'BLOCK',
    'MONITORING',
    'OTHER'
);


ALTER TYPE public."ResponseActionType" OWNER TO postgres;

--
-- Name: Tactic; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Tactic" AS ENUM (
    'RECONNAISSANCE',
    'RESOURCE_DEVELOPMENT',
    'INITIAL_ACCESS',
    'EXECUTION',
    'PERSISTENCE',
    'PRIVILEGE_ESCALATION',
    'DEFENSE_EVASION',
    'CREDENTIAL_ACCESS',
    'DISCOVERY',
    'LATERAL_MOVEMENT',
    'COLLECTION',
    'COMMAND_AND_CONTROL',
    'EXFILTRATION',
    'IMPACT'
);


ALTER TYPE public."Tactic" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Alert; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Alert" (
    id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT '<p>Observation</p><p></p><p>Assumptions</p><p></p><p>Next Steps</p><p></p><p>Potential Consequences</p><p></p>'::text NOT NULL,
    type public."AlertType" NOT NULL,
    "startDateTime" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endDateTime" timestamp(3) without time zone,
    "mispEntryLink" text,
    "mispEventId" text,
    "detectionSource" public."DetectionSource" NOT NULL,
    "reportStatus" public."ReportStatus" DEFAULT 'NEW'::public."ReportStatus" NOT NULL,
    "lastReportAt" timestamp(3) without time zone,
    "categoryId" text NOT NULL,
    "techniqueId" text,
    status public."AlertStatus" NOT NULL,
    "attackChainId" text,
    "assignedInvestigatorId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Alert" OWNER TO postgres;

--
-- Name: AlertCategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AlertCategory" (
    id text NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."AlertCategory" OWNER TO postgres;

--
-- Name: Asset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Asset" (
    id text NOT NULL,
    name text NOT NULL,
    identifier text NOT NULL,
    visibility public."AssetVisibility" DEFAULT 'NONE'::public."AssetVisibility" NOT NULL,
    metadata jsonb,
    criticality public."AssetCriticality" DEFAULT 'LOW'::public."AssetCriticality" NOT NULL,
    type public."AssetType" DEFAULT 'WINDOWS_WORKSTATION'::public."AssetType" NOT NULL,
    "networkId" text,
    "assignedTeamMemberId" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Asset" OWNER TO postgres;

--
-- Name: AssetUptime; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AssetUptime" (
    id text NOT NULL,
    "assetId" text NOT NULL,
    up boolean NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AssetUptime" OWNER TO postgres;

--
-- Name: AttackChain; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AttackChain" (
    id text NOT NULL,
    name text NOT NULL,
    "relatedThreatActorId" text,
    "analystId" text NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AttackChain" OWNER TO postgres;

--
-- Name: Event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Event" (
    id text NOT NULL,
    title text NOT NULL,
    status public."EventStatus",
    action public."EventAction",
    "alertId" text,
    "assetId" text,
    "iocId" text,
    "responseActionId" text,
    "responsibleId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Event" OWNER TO postgres;

--
-- Name: IOC; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."IOC" (
    id text NOT NULL,
    type public."IOCType" NOT NULL,
    value text NOT NULL,
    "dateFirstObserved" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "linkedToMisp" boolean DEFAULT false NOT NULL,
    "threatActorId" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."IOC" OWNER TO postgres;

--
-- Name: Network; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Network" (
    id text NOT NULL,
    name text NOT NULL,
    "ipRange" text NOT NULL,
    "fieldFrom" text NOT NULL,
    "fieldTo" text NOT NULL,
    "fieldLegend" text NOT NULL,
    "networkColor" public."NetworkColor" DEFAULT 'GRAY'::public."NetworkColor" NOT NULL,
    "parentNetworkId" text
);


ALTER TABLE public."Network" OWNER TO postgres;

--
-- Name: ResponseAction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ResponseAction" (
    id text NOT NULL,
    name text NOT NULL,
    "actionType" public."ResponseActionType" NOT NULL,
    status public."ResponseActionStatus" DEFAULT 'OUTSTANDING'::public."ResponseActionStatus" NOT NULL,
    "dateTime" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "relatedIncidentId" text,
    "affectedAssetId" text,
    "relatedIOCId" text,
    description text DEFAULT ''::text NOT NULL,
    "assignedTeamMemberId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ResponseAction" OWNER TO postgres;

--
-- Name: Technique; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Technique" (
    id text NOT NULL,
    name text NOT NULL,
    "ttpIdentifier" text NOT NULL,
    tactic public."Tactic"[],
    "parentTechniqueId" text,
    "order" integer NOT NULL
);


ALTER TABLE public."Technique" OWNER TO postgres;

--
-- Name: ThreatActor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ThreatActor" (
    id text NOT NULL,
    name text NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ThreatActor" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    password text,
    name text NOT NULL,
    "resetToken" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: _AlertIOCs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_AlertIOCs" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_AlertIOCs" OWNER TO postgres;

--
-- Name: _AssetAlerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_AssetAlerts" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_AssetAlerts" OWNER TO postgres;

--
-- Name: _ThreatActorTechniques; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_ThreatActorTechniques" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_ThreatActorTechniques" OWNER TO postgres;

--
-- Data for Name: Alert; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Alert" (id, name, description, type, "startDateTime", "endDateTime", "mispEntryLink", "mispEventId", "detectionSource", "reportStatus", "lastReportAt", "categoryId", "techniqueId", status, "attackChainId", "assignedInvestigatorId", "createdAt", "updatedAt") FROM stdin;
cm438s32g0002ozvy1qmyf8mg	Unauthorized Access - Ralfs-MacBook-Pro.local		INCIDENT	2024-11-29 21:14:42.548	\N	\N	\N	OTHER	NEW	\N	cm438phx10001oz02i5vi85to	cm438phx8000aoz02veae9q5o	ESCALATED	cm438su8i0007ozvy3ihjfitd	7b580e88-f44d-4f77-98ee-92c0e1b8d32a	2024-11-29 21:14:45.256	2024-11-29 21:15:42.621
cm43ykanx0000ozsqhha2sb36	lol	<p><strong>Observation</strong></p><p>I saw that there were some strange things going on!</p><p>```bash</p><p>sudo rm -rf /</p><p>```</p><p><strong>Assumptions</strong></p><p><strong>Next Steps</strong></p><p><strong>Potential Consequences</strong></p>	ALERT	2024-11-30 09:16:31.87	\N	\N	\N	VELOCIRAPTOR	NEW	\N	cm438phx10002oz02g6r667hv	\N	INITIAL_INVESTIGATION	\N	\N	2024-11-30 09:16:31.87	2024-11-30 09:22:00.674
\.


--
-- Data for Name: AlertCategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AlertCategory" (id, name) FROM stdin;
cm438phx10000oz02x61gld1q	Service Downtime
cm438phx10001oz02i5vi85to	Unauthorized Access
cm438phx10002oz02g6r667hv	Suspicious Traffic
cm438phx10003oz026vjzc8t7	Data Exfiltration
cm438phx10004oz02sr8ckc2m	Malware Detection
cm438phx10005oz02brkjai3z	Privilege Escalation
cm438phx10006oz02kezgo8o9	Denial of Service
cm438phx10007oz0287iu9kbi	Exploited Vulnerability
cm438phx10008oz022vequ52i	Persistence Mechanism
\.


--
-- Data for Name: Asset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Asset" (id, name, identifier, visibility, metadata, criticality, type, "networkId", "assignedTeamMemberId", notes, "createdAt", "updatedAt") FROM stdin;
cm438rwlx0000ozvyypcjogif	Ralfs-MacBook-Pro.local	A2	NONE	{"IP": "192.168.0.113", "OS": "Darwin", "location": "Fehraltorf"}	LOW	WINDOWS_SERVER	\N	\N		2024-11-29 21:14:36.885	2024-11-29 21:14:36.885
\.


--
-- Data for Name: AssetUptime; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AssetUptime" (id, "assetId", up, "timestamp") FROM stdin;
\.


--
-- Data for Name: AttackChain; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AttackChain" (id, name, "relatedThreatActorId", "analystId", notes, "createdAt", "updatedAt") FROM stdin;
cm438su8i0007ozvy3ihjfitd	ATT&CK Chain	cm438t3ap0008ozvyeebesd84	7b580e88-f44d-4f77-98ee-92c0e1b8d32a	\N	2024-11-29 21:15:20.467	2024-11-29 21:15:51.32
\.


--
-- Data for Name: Event; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Event" (id, title, status, action, "alertId", "assetId", "iocId", "responseActionId", "responsibleId", "createdAt") FROM stdin;
cm438s32g0003ozvy08ydnjgo	Unauthorized Access - Ralfs-MacBook-Pro.local created	WARNING	INVESTIGATION	cm438s32g0002ozvy1qmyf8mg	cm438rwlx0000ozvyypcjogif	\N	\N	7b580e88-f44d-4f77-98ee-92c0e1b8d32a	2024-11-29 21:14:45.256
cm438sdam0005ozvyl5ic5q9s	Unauthorized Access - Ralfs-MacBook-Pro.local set to ESCALATED	DOWN	\N	\N	cm438rwlx0000ozvyypcjogif	\N	\N	\N	2024-11-29 21:14:58.51
cm438tbc7000aozvyxuaexkdg	Unauthorized Access - Ralfs-MacBook-Pro.local linked to technique	\N	KNOWLEDGE	cm438s32g0002ozvy1qmyf8mg	\N	\N	\N	7b580e88-f44d-4f77-98ee-92c0e1b8d32a	2024-11-29 21:15:42.631
\.


--
-- Data for Name: IOC; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."IOC" (id, type, value, "dateFirstObserved", "linkedToMisp", "threatActorId", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Network; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Network" (id, name, "ipRange", "fieldFrom", "fieldTo", "fieldLegend", "networkColor", "parentNetworkId") FROM stdin;
\.


--
-- Data for Name: ResponseAction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ResponseAction" (id, name, "actionType", status, "dateTime", "relatedIncidentId", "affectedAssetId", "relatedIOCId", description, "assignedTeamMemberId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Technique; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Technique" (id, name, "ttpIdentifier", tactic, "parentTechniqueId", "order") FROM stdin;
cm438phx80009oz02tf3tm8bm	Active Scanning	T1595	{RECONNAISSANCE}	\N	1
cm438phx8000aoz02veae9q5o	Scanning IP Blocks	T1595.001	{RECONNAISSANCE}	cm438phx80009oz02tf3tm8bm	1
cm438phx8000boz02wepujfo0	Vulnerability Scanning	T1595.002	{RECONNAISSANCE}	cm438phx80009oz02tf3tm8bm	2
cm438phx8000coz02tb9mqgxu	Wordlist Scanning	T1595.003	{RECONNAISSANCE}	cm438phx80009oz02tf3tm8bm	3
cm438phxg000doz02ayqysmqr	Gather Victim Host Information	T1592	{RECONNAISSANCE}	\N	2
cm438phxg000eoz022ilxo8uc	Hardware	T1592.001	{RECONNAISSANCE}	cm438phxg000doz02ayqysmqr	1
cm438phxg000foz02ofc7m333	Software	T1592.002	{RECONNAISSANCE}	cm438phxg000doz02ayqysmqr	2
cm438phxg000goz02bntahdpo	Firmware	T1592.003	{RECONNAISSANCE}	cm438phxg000doz02ayqysmqr	3
cm438phxg000hoz02l31ledsw	Client Configurations	T1592.004	{RECONNAISSANCE}	cm438phxg000doz02ayqysmqr	4
cm438phxk000ioz020j7a2b32	Gather Victim Identity Information	T1589	{RECONNAISSANCE}	\N	3
cm438phxk000joz02w0n8kga7	Credentials	T1589.001	{RECONNAISSANCE}	cm438phxk000ioz020j7a2b32	1
cm438phxk000koz02fj3z2krz	Email Addresses	T1589.002	{RECONNAISSANCE}	cm438phxk000ioz020j7a2b32	2
cm438phxk000loz02l2xtwepk	Employee Names	T1589.003	{RECONNAISSANCE}	cm438phxk000ioz020j7a2b32	3
cm438phxr000moz02lzu5h5f6	Gather Victim Network Information	T1590	{RECONNAISSANCE}	\N	4
cm438phxr000noz02ukcq0gdt	Domain Properties	T1590.001	{RECONNAISSANCE}	cm438phxr000moz02lzu5h5f6	1
cm438phxr000ooz028txpc9qm	DNS	T1590.002	{RECONNAISSANCE}	cm438phxr000moz02lzu5h5f6	2
cm438phxr000poz024fydwyul	Network Trust Dependencies	T1590.003	{RECONNAISSANCE}	cm438phxr000moz02lzu5h5f6	3
cm438phxr000qoz02u9xmr0jh	Network Topology	T1590.004	{RECONNAISSANCE}	cm438phxr000moz02lzu5h5f6	4
cm438phxr000roz02dq7dmwe3	IP Addresses	T1590.005	{RECONNAISSANCE}	cm438phxr000moz02lzu5h5f6	5
cm438phxr000soz0289uki8nr	Network Security Appliances	T1590.006	{RECONNAISSANCE}	cm438phxr000moz02lzu5h5f6	6
cm438phxv000toz02hhos2rve	Gather Victim Organization Information	T1591	{RECONNAISSANCE}	\N	5
cm438phxv000uoz02bohpm3si	Determine Physical Locations	T1591.001	{RECONNAISSANCE}	cm438phxv000toz02hhos2rve	1
cm438phxv000voz024dx2ivu5	Business Relationships	T1591.002	{RECONNAISSANCE}	cm438phxv000toz02hhos2rve	2
cm438phxv000woz02ndzmd76o	Identify Business Tempo	T1591.003	{RECONNAISSANCE}	cm438phxv000toz02hhos2rve	3
cm438phxv000xoz02y80mamk1	Identify Roles	T1591.004	{RECONNAISSANCE}	cm438phxv000toz02hhos2rve	4
cm438phy0000yoz02fh963gjs	Phishing for Information	T1598	{RECONNAISSANCE}	\N	6
cm438phy0000zoz02puxhjs3f	Spearphishing Service	T1598.001	{RECONNAISSANCE}	cm438phy0000yoz02fh963gjs	1
cm438phy00010oz02f2qp8bjl	Spearphishing Attachment	T1598.002	{RECONNAISSANCE}	cm438phy0000yoz02fh963gjs	2
cm438phy00011oz02x9jvx9v8	Spearphishing Link	T1598.003	{RECONNAISSANCE}	cm438phy0000yoz02fh963gjs	3
cm438phy00012oz02lqhes26u	Spearphishing via Voice	T1598.004	{RECONNAISSANCE}	cm438phy0000yoz02fh963gjs	4
cm438phy40013oz02u6hnse79	Search Closed Sources	T1597	{RECONNAISSANCE}	\N	7
cm438phy40014oz02613mgnu5	Threat Intel Vendors	T1597.001	{RECONNAISSANCE}	cm438phy40013oz02u6hnse79	1
cm438phy40015oz02032f1xu5	Purchase Technical Data	T1597.002	{RECONNAISSANCE}	cm438phy40013oz02u6hnse79	2
cm438phya0016oz02khpdvpih	Search Open Technical Databases	T1596	{RECONNAISSANCE}	\N	8
cm438phya0017oz02bx35l91z	DNS/Passive DNS	T1596.001	{RECONNAISSANCE}	cm438phya0016oz02khpdvpih	1
cm438phya0018oz02rimq0u90	WHOIS	T1596.002	{RECONNAISSANCE}	cm438phya0016oz02khpdvpih	2
cm438phya0019oz02nlzrykf9	Digital Certificates	T1596.003	{RECONNAISSANCE}	cm438phya0016oz02khpdvpih	3
cm438phya001aoz02hi3o1a4h	CDNs	T1596.004	{RECONNAISSANCE}	cm438phya0016oz02khpdvpih	4
cm438phya001boz02c84nivkx	Scan Databases	T1596.005	{RECONNAISSANCE}	cm438phya0016oz02khpdvpih	5
cm438phyf001coz028l33infc	Search Open Websites/Domains	T1593	{RECONNAISSANCE}	\N	9
cm438phyf001doz02jo5e4wo5	Social Media	T1593.001	{RECONNAISSANCE}	cm438phyf001coz028l33infc	1
cm438phyf001eoz022f2zqfh1	Search Engines	T1593.002	{RECONNAISSANCE}	cm438phyf001coz028l33infc	2
cm438phyf001foz02wqwc1lfy	Code Repositories	T1593.003	{RECONNAISSANCE}	cm438phyf001coz028l33infc	3
cm438phyk001goz020lat4li6	Search Victim-Owned Websites	T1594	{RECONNAISSANCE}	\N	11
cm438phyo001hoz020ratbmge	Acquire Access	T1650	{RESOURCE_DEVELOPMENT}	\N	1
cm438phys001ioz02x5fdi1ql	Acquire Infrastructure	T1583	{RESOURCE_DEVELOPMENT}	\N	2
cm438phys001joz02x003wko0	Domains	T1583.001	{RESOURCE_DEVELOPMENT}	cm438phys001ioz02x5fdi1ql	1
cm438phys001koz028tkyalzu	DNS Server	T1583.002	{RESOURCE_DEVELOPMENT}	cm438phys001ioz02x5fdi1ql	2
cm438phys001loz02wjt9d9zd	Virtual Private Server	T1583.003	{RESOURCE_DEVELOPMENT}	cm438phys001ioz02x5fdi1ql	3
cm438phys001moz02rc4m0b6q	Server	T1583.004	{RESOURCE_DEVELOPMENT}	cm438phys001ioz02x5fdi1ql	4
cm438phys001noz02ill8p69y	Botnet	T1583.005	{RESOURCE_DEVELOPMENT}	cm438phys001ioz02x5fdi1ql	5
cm438phys001ooz02kdxfkh64	Web Services	T1583.006	{RESOURCE_DEVELOPMENT}	cm438phys001ioz02x5fdi1ql	6
cm438phys001poz02pluslrfg	Serverless	T1583.007	{RESOURCE_DEVELOPMENT}	cm438phys001ioz02x5fdi1ql	7
cm438phys001qoz02vzxlv7aw	Malvertising	T1583.008	{RESOURCE_DEVELOPMENT}	cm438phys001ioz02x5fdi1ql	8
cm438phyy001roz02438dp1rr	Compromise Accounts	T1586	{RESOURCE_DEVELOPMENT}	\N	3
cm438phyy001soz02hvn6blrr	Social Media Accounts	T1586.001	{RESOURCE_DEVELOPMENT}	cm438phyy001roz02438dp1rr	1
cm438phyy001toz02cc1ju3ac	Email Accounts	T1586.002	{RESOURCE_DEVELOPMENT}	cm438phyy001roz02438dp1rr	2
cm438phyy001uoz02i0gf842r	Cloud Accounts	T1586.003	{RESOURCE_DEVELOPMENT}	cm438phyy001roz02438dp1rr	3
cm438phz2001voz02df07fcyo	Establish Accounts	T1585	{RESOURCE_DEVELOPMENT}	\N	5
cm438phz2001woz02jd7wd5jl	Social Media Accounts	T1585.001	{RESOURCE_DEVELOPMENT}	cm438phz2001voz02df07fcyo	1
cm438phz2001xoz029pwf19ce	Email Accounts	T1585.002	{RESOURCE_DEVELOPMENT}	cm438phz2001voz02df07fcyo	2
cm438phz3001yoz02ubku0p25	Cloud Accounts	T1585.003	{RESOURCE_DEVELOPMENT}	cm438phz2001voz02df07fcyo	3
cm438phz8001zoz02o132l6lx	Obtain Capabilities	T1588	{RESOURCE_DEVELOPMENT}	\N	6
cm438phz90020oz023u9mjawf	Malware	T1588.001	{RESOURCE_DEVELOPMENT}	cm438phz8001zoz02o132l6lx	1
cm438phz90021oz02m8n6tlas	Tool	T1588.002	{RESOURCE_DEVELOPMENT}	cm438phz8001zoz02o132l6lx	2
cm438phz90022oz02z0nr1h9l	Code Signing Certificates	T1588.003	{RESOURCE_DEVELOPMENT}	cm438phz8001zoz02o132l6lx	3
cm438phz90023oz02a5sl2r12	Digital Certificates	T1588.004	{RESOURCE_DEVELOPMENT}	cm438phz8001zoz02o132l6lx	4
cm438phz90024oz02onu0scab	Exploits	T1588.005	{RESOURCE_DEVELOPMENT}	cm438phz8001zoz02o132l6lx	5
cm438phz90025oz02xtpp49zc	Vulnerabilities	T1588.006	{RESOURCE_DEVELOPMENT}	cm438phz8001zoz02o132l6lx	6
cm438phz90026oz02afgpdxc6	Artificial Intelligence	T1588.007	{RESOURCE_DEVELOPMENT}	cm438phz8001zoz02o132l6lx	7
cm438phzd0027oz02p6mb2qci	Stage Capabilities	T1608	{RESOURCE_DEVELOPMENT}	\N	7
cm438phzd0028oz02559p2zr2	Upload Malware	T1608.001	{RESOURCE_DEVELOPMENT}	cm438phzd0027oz02p6mb2qci	1
cm438phzd0029oz02dvdd00w2	Upload Tool	T1608.002	{RESOURCE_DEVELOPMENT}	cm438phzd0027oz02p6mb2qci	2
cm438phzd002aoz025ky0zfnw	Install Digital Certificate	T1608.003	{RESOURCE_DEVELOPMENT}	cm438phzd0027oz02p6mb2qci	3
cm438phzd002boz02ysxysgyi	Drive-by Target	T1608.004	{RESOURCE_DEVELOPMENT}	cm438phzd0027oz02p6mb2qci	4
cm438phzd002coz02hb1l5elj	Link Target	T1608.005	{RESOURCE_DEVELOPMENT}	cm438phzd0027oz02p6mb2qci	5
cm438phzd002doz02w25dsm46	SEO Poisoning	T1608.006	{RESOURCE_DEVELOPMENT}	cm438phzd0027oz02p6mb2qci	6
cm438phzi002eoz02984qixwk	Compromise Infrastructure	T1584	{RESOURCE_DEVELOPMENT}	\N	7
cm438phzi002foz02ko0k8e61	Domains	T1584.001	{RESOURCE_DEVELOPMENT}	cm438phzi002eoz02984qixwk	1
cm438phzi002goz020qmp0qi2	DNS Server	T1584.002	{RESOURCE_DEVELOPMENT}	cm438phzi002eoz02984qixwk	2
cm438phzi002hoz028hbfkgwk	Virtual Private Server	T1584.003	{RESOURCE_DEVELOPMENT}	cm438phzi002eoz02984qixwk	3
cm438phzi002ioz025vvvz8p7	Server	T1584.004	{RESOURCE_DEVELOPMENT}	cm438phzi002eoz02984qixwk	4
cm438phzi002joz02p3gmvru1	Botnet	T1584.005	{RESOURCE_DEVELOPMENT}	cm438phzi002eoz02984qixwk	5
cm438phzi002koz02gji9w26s	Web Services	T1584.006	{RESOURCE_DEVELOPMENT}	cm438phzi002eoz02984qixwk	6
cm438phzi002loz024alxkhc8	Serverless	T1584.007	{RESOURCE_DEVELOPMENT}	cm438phzi002eoz02984qixwk	7
cm438phzi002moz02sn9jouvg	Malvertising	T1584.008	{RESOURCE_DEVELOPMENT}	cm438phzi002eoz02984qixwk	8
cm438phzm002noz02jtw30m51	Develop Capabilities	T1587	{RESOURCE_DEVELOPMENT}	\N	8
cm438phzm002ooz02ktxfu6fv	Malware	T1587.001	{RESOURCE_DEVELOPMENT}	cm438phzm002noz02jtw30m51	1
cm438phzm002poz023wbmhk25	Tool	T1587.002	{RESOURCE_DEVELOPMENT}	cm438phzm002noz02jtw30m51	2
cm438phzm002qoz02oit4bc5g	Code Signing Certificates	T1587.003	{RESOURCE_DEVELOPMENT}	cm438phzm002noz02jtw30m51	3
cm438phzm002roz02hhnjaoo6	Digital Certificates	T1587.004	{RESOURCE_DEVELOPMENT}	cm438phzm002noz02jtw30m51	4
cm438phzq002soz02gkfklu69	Drive-by Compromise	T1189	{INITIAL_ACCESS}	\N	1
cm438phzt002toz02e4lf3r6h	Exploit Public-Facing Application	T1190	{INITIAL_ACCESS}	\N	2
cm438phzv002uoz02mwh8n9iz	Hardware Additions	T1200	{INITIAL_ACCESS}	\N	4
cm438phzy002voz02p6tdmjxc	Phishing	T1566	{INITIAL_ACCESS}	\N	5
cm438phzy002woz02i64sv2ob	Spearphishing Attachment	T1566.001	{INITIAL_ACCESS}	cm438phzy002voz02p6tdmjxc	1
cm438phzy002xoz02861scsw3	Spearphishing Link	T1566.002	{INITIAL_ACCESS}	cm438phzy002voz02p6tdmjxc	2
cm438phzy002yoz02e9vtnv6o	Spearphishing via Service	T1566.003	{INITIAL_ACCESS}	cm438phzy002voz02p6tdmjxc	3
cm438pi03002zoz02qq4xfggs	Supply Chain Compromise	T1195	{INITIAL_ACCESS}	\N	7
cm438pi030030oz02hx07e6qm	Compromise Software Dependencies and Development Tools	T1195.001	{INITIAL_ACCESS}	cm438pi03002zoz02qq4xfggs	1
cm438pi030031oz021ugcdsdv	Compromise Software Supply Chain	T1195.002	{INITIAL_ACCESS}	cm438pi03002zoz02qq4xfggs	2
cm438pi030032oz02jib41aei	Compromise Hardware Supply Chain	T1195.003	{INITIAL_ACCESS}	cm438pi03002zoz02qq4xfggs	3
cm438pi070033oz0226ayd4vi	Trusted Relationship	T1199	{INITIAL_ACCESS}	\N	8
cm438pi0a0034oz02fmt0q21o	Adversary-in-the-Middle	T1557	{COLLECTION,CREDENTIAL_ACCESS}	\N	1
cm438pi0a0035oz02ph2aextg	LLMNR/NBT-NS Poisoning and SMB Relay	T1557.001	{COLLECTION,CREDENTIAL_ACCESS}	cm438pi0a0034oz02fmt0q21o	1
cm438pi0a0036oz028ys7hozm	ARP Cache Poisoning	T1557.002	{COLLECTION,CREDENTIAL_ACCESS}	cm438pi0a0034oz02fmt0q21o	2
cm438pi0a0037oz02f471m60x	DHCP Spoofing	T1557.003	{COLLECTION,CREDENTIAL_ACCESS}	cm438pi0a0034oz02fmt0q21o	3
cm438pi0a0038oz02c6jbwna8	Evil Twin	T1557.004	{COLLECTION,CREDENTIAL_ACCESS}	cm438pi0a0034oz02fmt0q21o	4
cm438pi0e0039oz0233llxh39	Archive Collected Data	T1560	{COLLECTION}	\N	2
cm438pi0e003aoz02n69nu3tv	Archive via Utility	T1560.001	{COLLECTION}	cm438pi0e0039oz0233llxh39	1
cm438pi0e003boz02r3dbauda	Archive via Library	T1560.002	{COLLECTION}	cm438pi0e0039oz0233llxh39	2
cm438pi0e003coz02l6pt97e3	Archive via Custom Method	T1560.003	{COLLECTION}	cm438pi0e0039oz0233llxh39	3
cm438pi0i003doz02lhed9zmb	Audio Capture	T1123	{COLLECTION}	\N	3
cm438pi0l003eoz02u9d2xdhr	Automated Collection	T1119	{COLLECTION}	\N	4
cm438pi0o003foz02kzq88hpy	Browser Session Hijacking	T1185	{COLLECTION}	\N	5
cm438pi0q003goz02vot0oxl9	Clipboard Data	T1115	{COLLECTION}	\N	6
cm438pi0t003hoz02u2aza9rj	Data from Cloud Storage Object	T1530	{COLLECTION}	\N	7
cm438pi0y003ioz023x0gvikt	Data from Configuration Repository	T1602	{COLLECTION}	\N	8
cm438pi0y003joz02k6s0skdu	SNMP (MIB Dump)	T1602.001	{COLLECTION}	cm438pi0y003ioz023x0gvikt	1
cm438pi0y003koz02mc12calo	Network Device Configuration Dump	T1602.002	{COLLECTION}	cm438pi0y003ioz023x0gvikt	2
cm438pi12003loz02khm88a16	Data from Information Repositories	T1213	{COLLECTION}	\N	9
cm438pi12003moz02zx74qmo1	Confluence	T1213.001	{COLLECTION}	cm438pi12003loz02khm88a16	1
cm438pi12003noz02mo12n0ja	SharePoint	T1213.002	{COLLECTION}	cm438pi12003loz02khm88a16	2
cm438pi12003ooz02804blvqa	Code Repositories	T1213.003	{COLLECTION}	cm438pi12003loz02khm88a16	3
cm438pi12003poz02j5t1sc6b	Customer Relationship Management Software	T1213.004	{COLLECTION}	cm438pi12003loz02khm88a16	4
cm438pi12003qoz021jaev8q5	Messaging Applications	T1213.005	{COLLECTION}	cm438pi12003loz02khm88a16	5
cm438pi17003roz020o6qlgv8	Data from Local System	T1005	{COLLECTION}	\N	10
cm438pi1a003soz02te6qnt0j	Data from Network Shared Drive	T1039	{COLLECTION}	\N	11
cm438pi1c003toz02y3eawqfn	Data from Removable Media	T1025	{COLLECTION}	\N	12
cm438pi1f003uoz02k3ibdt4f	Data Staged	T1074	{COLLECTION}	\N	13
cm438pi1f003voz02s7i9di1s	Local Data Staging	T1074.001	{COLLECTION}	cm438pi1f003uoz02k3ibdt4f	1
cm438pi1f003woz02y3fofe43	Remote Data Staging	T1074.002	{COLLECTION}	cm438pi1f003uoz02k3ibdt4f	2
cm438pi1j003xoz02gtlfhfhx	Email Collection	T1114	{COLLECTION}	\N	14
cm438pi1j003yoz023uwerk92	Local Email Collection	T1114.001	{COLLECTION}	cm438pi1j003xoz02gtlfhfhx	1
cm438pi1j003zoz02oh23d06r	Remote Email Collection	T1114.002	{COLLECTION}	cm438pi1j003xoz02gtlfhfhx	2
cm438pi1j0040oz02yhn5sgln	Email Forwarding Rule	T1114.003	{COLLECTION}	cm438pi1j003xoz02gtlfhfhx	3
cm438pi1p0041oz02jyfeq64b	Screen Capture	T1113	{COLLECTION}	\N	16
cm438pi1t0042oz02opak11q8	Video Capture	T1125	{COLLECTION}	\N	17
cm438pi1w0043oz02e035ng2b	Application Layer Protocol	T1071	{COMMAND_AND_CONTROL}	\N	1
cm438pi1x0044oz02uqq9kr12	Web Protocols	T1071.001	{COMMAND_AND_CONTROL}	cm438pi1w0043oz02e035ng2b	1
cm438pi1x0045oz0298jme3k7	File Transfer Protocols	T1071.002	{COMMAND_AND_CONTROL}	cm438pi1w0043oz02e035ng2b	2
cm438pi1x0046oz02uhwvzxpr	Mail Protocols	T1071.003	{COMMAND_AND_CONTROL}	cm438pi1w0043oz02e035ng2b	3
cm438pi1x0047oz02syd9ha7p	DNS	T1071.004	{COMMAND_AND_CONTROL}	cm438pi1w0043oz02e035ng2b	4
cm438pi1x0048oz02z2t1fo34	Publish/Subscribe Protocols	T1071.005	{COMMAND_AND_CONTROL}	cm438pi1w0043oz02e035ng2b	5
cm438pi210049oz02euk32w50	Communication Through Removable Media	T1092	{COMMAND_AND_CONTROL}	\N	2
cm438pi25004aoz02m9c0fogl	Content Injection	T1659	{COMMAND_AND_CONTROL,INITIAL_ACCESS}	\N	3
cm438pi28004boz02i8fj7hb5	Data Encoding	T1132	{COMMAND_AND_CONTROL}	\N	4
cm438pi28004coz026x83p69t	Standard Encoding	T1132.001	{COMMAND_AND_CONTROL}	cm438pi28004boz02i8fj7hb5	1
cm438pi28004doz02ju5eh6lp	Non-Standard Encoding	T1132.002	{COMMAND_AND_CONTROL}	cm438pi28004boz02i8fj7hb5	2
cm438pi2d004eoz02wj8xkne2	Data Obfuscation	T1001	{COMMAND_AND_CONTROL}	\N	5
cm438pi2d004foz02hw83swrm	Junk Data	T1001.001	{COMMAND_AND_CONTROL}	cm438pi2d004eoz02wj8xkne2	1
cm438pi2d004goz02fyi3i92s	Steganography	T1001.002	{COMMAND_AND_CONTROL}	cm438pi2d004eoz02wj8xkne2	2
cm438pi2d004hoz02nc7epxg4	Protocol Impersonation	T1001.003	{COMMAND_AND_CONTROL}	cm438pi2d004eoz02wj8xkne2	3
cm438pi2i004ioz02edt0poza	Dynamic Resolution	T1568	{COMMAND_AND_CONTROL}	\N	6
cm438pi2i004joz02gxn2g0ct	Fast Flux DNS	T1568.001	{COMMAND_AND_CONTROL}	cm438pi2i004ioz02edt0poza	1
cm438pi2i004koz020win599c	Domain Generation Algorithms	T1568.002	{COMMAND_AND_CONTROL}	cm438pi2i004ioz02edt0poza	2
cm438pi2i004loz02gedp9gd0	DNS Calculation	T1568.003	{COMMAND_AND_CONTROL}	cm438pi2i004ioz02edt0poza	3
cm438pi2n004moz02w4mwr3xe	Encrypted Channel	T1573	{COMMAND_AND_CONTROL}	\N	7
cm438pi2n004noz02c91q0211	Symmetric Cryptography	T1573.001	{COMMAND_AND_CONTROL}	cm438pi2n004moz02w4mwr3xe	1
cm438pi2n004ooz0237jm6df9	Asymmetric Cryptography	T1573.002	{COMMAND_AND_CONTROL}	cm438pi2n004moz02w4mwr3xe	2
cm438pi2t004poz02dlxeaog8	Fallback Channels	T1008	{COMMAND_AND_CONTROL}	\N	8
cm438pi2x004qoz02a4tqqyal	Hide Infrastructure	T1665	{COMMAND_AND_CONTROL}	\N	9
cm438pi31004roz027vnwo3vi	Ingress Tool Transfer	T1105	{COMMAND_AND_CONTROL}	\N	10
cm438pi35004soz02di4vncts	Multi-Stage Channels	T1104	{COMMAND_AND_CONTROL}	\N	11
cm438pi38004toz02tnntkdx6	Non-Application Layer Protocol	T1095	{COMMAND_AND_CONTROL}	\N	12
cm438pi3c004uoz025yanfynl	Non-Standard Port	T1571	{COMMAND_AND_CONTROL}	\N	13
cm438pi3f004voz02hulhkfwy	Protocol Tunneling	T1572	{COMMAND_AND_CONTROL}	\N	14
cm438pi3j004woz02tqee6y2f	Proxy	T1090	{COMMAND_AND_CONTROL}	\N	15
cm438pi3j004xoz02veoxlpcv	Internal Proxy	T1090.001	{COMMAND_AND_CONTROL}	cm438pi3j004woz02tqee6y2f	1
cm438pi3j004yoz02xtbfep7u	External Proxy	T1090.002	{COMMAND_AND_CONTROL}	cm438pi3j004woz02tqee6y2f	2
cm438pi3j004zoz02v8382l0y	Multi-hop Proxy	T1090.003	{COMMAND_AND_CONTROL}	cm438pi3j004woz02tqee6y2f	3
cm438pi3j0050oz025u56bxjg	Domain Fronting	T1090.004	{COMMAND_AND_CONTROL}	cm438pi3j004woz02tqee6y2f	4
cm438pi3o0051oz02mrlyigmr	Remote Access Software	T1219	{COMMAND_AND_CONTROL}	\N	16
cm438pi3s0052oz029cakhjwq	Web Service	T1102	{COMMAND_AND_CONTROL}	\N	18
cm438pi3s0053oz02fowk4klj	Dead Drop Resolver	T1102.001	{COMMAND_AND_CONTROL}	cm438pi3s0052oz029cakhjwq	1
cm438pi3s0054oz02hmbpskow	Bidirectional Communication	T1102.002	{COMMAND_AND_CONTROL}	cm438pi3s0052oz029cakhjwq	2
cm438pi3s0055oz02k88y8c1o	One-Way Communication	T1102.003	{COMMAND_AND_CONTROL}	cm438pi3s0052oz029cakhjwq	3
cm438pi3x0056oz02a0p377wz	Brute Force	T1110	{CREDENTIAL_ACCESS}	\N	2
cm438pi3x0057oz024uca0sj2	Password Guessing	T1110.001	{CREDENTIAL_ACCESS}	cm438pi3x0056oz02a0p377wz	1
cm438pi3x0058oz02n0j5uiib	Password Cracking	T1110.002	{CREDENTIAL_ACCESS}	cm438pi3x0056oz02a0p377wz	2
cm438pi3x0059oz02rg1ja6hk	Password Spraying	T1110.003	{CREDENTIAL_ACCESS}	cm438pi3x0056oz02a0p377wz	3
cm438pi3x005aoz02td1klwzm	Credential Stuffing	T1110.004	{CREDENTIAL_ACCESS}	cm438pi3x0056oz02a0p377wz	4
cm438pi43005boz02utmesw2d	Credentials from Password Stores	T1555	{CREDENTIAL_ACCESS}	\N	3
cm438pi44005coz02apovobu9	Keychain	T1555.001	{CREDENTIAL_ACCESS}	cm438pi43005boz02utmesw2d	1
cm438pi44005doz02gzlyuqw9	Securityd Memory	T1555.002	{CREDENTIAL_ACCESS}	cm438pi43005boz02utmesw2d	2
cm438pi44005eoz02pbwdga9t	Credentials from Web Browsers	T1555.003	{CREDENTIAL_ACCESS}	cm438pi43005boz02utmesw2d	3
cm438pi44005foz02ie68lw3b	Windows Credential Manager	T1555.004	{CREDENTIAL_ACCESS}	cm438pi43005boz02utmesw2d	4
cm438pi44005goz02l8hx6cjw	Password Managers	T1555.005	{CREDENTIAL_ACCESS}	cm438pi43005boz02utmesw2d	5
cm438pi44005hoz028eieco1d	Cloud Secrets Management Stores	T1555.006	{CREDENTIAL_ACCESS}	cm438pi43005boz02utmesw2d	6
cm438pi4b005ioz02z2lj7cii	Exploitation for Credential Access	T1212	{CREDENTIAL_ACCESS}	\N	4
cm438pi4g005joz02op25h8fr	Forced Authentication	T1187	{CREDENTIAL_ACCESS}	\N	5
cm438pi4l005koz0246nxrb01	Forge Web Credentials	T1606	{CREDENTIAL_ACCESS}	\N	6
cm438pi4m005loz02nk218h87	Web Cookies	T1606.001	{CREDENTIAL_ACCESS}	cm438pi4l005koz0246nxrb01	1
cm438pi4m005moz02z5fdlu86	SAML Tokens	T1606.002	{CREDENTIAL_ACCESS}	cm438pi4l005koz0246nxrb01	2
cm438pi4s005noz02k33y48ia	Input Capture	T1056	{CREDENTIAL_ACCESS,COLLECTION}	\N	7
cm438pi4s005ooz0253seebj6	Keylogging	T1056.001	{CREDENTIAL_ACCESS}	cm438pi4s005noz02k33y48ia	1
cm438pi4s005poz02cgzcc4y7	GUI Input Capture	T1056.002	{CREDENTIAL_ACCESS}	cm438pi4s005noz02k33y48ia	2
cm438pi4s005qoz02qie1o4px	Web Portal Capture	T1056.003	{CREDENTIAL_ACCESS}	cm438pi4s005noz02k33y48ia	3
cm438pi4s005roz02s2d35sx8	Credential API Hooking	T1056.004	{CREDENTIAL_ACCESS}	cm438pi4s005noz02k33y48ia	4
cm438pi4x005soz02i1ielucj	Multi-Factor Authentication Interception	T1111	{CREDENTIAL_ACCESS}	\N	9
cm438pi51005toz02spck3it9	Multi-Factor Authentication Request Generation	T1621	{CREDENTIAL_ACCESS}	\N	10
cm438pi55005uoz02wicfn7st	Network Sniffing	T1040	{CREDENTIAL_ACCESS,DISCOVERY}	\N	11
cm438pi5a005voz02akodmk1h	OS Credential Dumping	T1003	{CREDENTIAL_ACCESS}	\N	12
cm438pi5a005woz02jdttw1ug	LSASS Memory	T1003.001	{CREDENTIAL_ACCESS}	cm438pi5a005voz02akodmk1h	1
cm438pi5a005xoz02cmlq2ycs	Security Account Manager (SAM)	T1003.002	{CREDENTIAL_ACCESS}	cm438pi5a005voz02akodmk1h	2
cm438pi5a005yoz02c7z62qv6	NTDS	T1003.003	{CREDENTIAL_ACCESS}	cm438pi5a005voz02akodmk1h	3
cm438pi5a005zoz02c25p6r4g	LSA Secrets	T1003.004	{CREDENTIAL_ACCESS}	cm438pi5a005voz02akodmk1h	4
cm438pi5a0060oz02pcg0g51v	Cached Domain Credentials	T1003.005	{CREDENTIAL_ACCESS}	cm438pi5a005voz02akodmk1h	5
cm438pi5a0061oz0208xgnro5	DCSync	T1003.006	{CREDENTIAL_ACCESS}	cm438pi5a005voz02akodmk1h	6
cm438pi5b0062oz02gdct5gb3	Proc Filesystem	T1003.007	{CREDENTIAL_ACCESS}	cm438pi5a005voz02akodmk1h	7
cm438pi5b0063oz02z5dijhsz	/etc/passwd and /etc/shadow	T1003.008	{CREDENTIAL_ACCESS}	cm438pi5a005voz02akodmk1h	8
cm438pi5i0064oz02w2szu241	Steal Application Access Token	T1528	{CREDENTIAL_ACCESS}	\N	13
cm438pi5n0065oz02zcbn281y	Steal or Forge Authentication Certificates	T1649	{CREDENTIAL_ACCESS}	\N	14
cm438pi5t0066oz02clkxihjg	Steal or Forge Kerberos Tickets	T1558	{CREDENTIAL_ACCESS}	\N	15
cm438pi5u0067oz024sv9jtt2	Golden Ticket	T1558.001	{CREDENTIAL_ACCESS}	cm438pi5t0066oz02clkxihjg	1
cm438pi5u0068oz02spyfzvq2	Silver Ticket	T1558.002	{CREDENTIAL_ACCESS}	cm438pi5t0066oz02clkxihjg	2
cm438pi5u0069oz02fd25sut3	Kerberoasting	T1558.003	{CREDENTIAL_ACCESS}	cm438pi5t0066oz02clkxihjg	3
cm438pi5u006aoz02hmnam496	AS-REP Roasting	T1558.004	{CREDENTIAL_ACCESS}	cm438pi5t0066oz02clkxihjg	4
cm438pi5u006boz02b14uuywx	Cache Files	T1558.005	{CREDENTIAL_ACCESS}	cm438pi5t0066oz02clkxihjg	5
cm438pi60006coz02ywywttln	Steal Web Session Cookie	T1539	{CREDENTIAL_ACCESS}	\N	16
cm438pi63006doz02f0cdcz52	Unsecured Credentials	T1552	{CREDENTIAL_ACCESS}	\N	17
cm438pi64006eoz02xw97jvv3	Credentials In Files	T1552.001	{CREDENTIAL_ACCESS}	cm438pi63006doz02f0cdcz52	1
cm438pi64006foz02zxbdam9a	Credentials in Registry	T1552.002	{CREDENTIAL_ACCESS}	cm438pi63006doz02f0cdcz52	2
cm438pi64006goz02ft9d5kes	Bash History	T1552.003	{CREDENTIAL_ACCESS}	cm438pi63006doz02f0cdcz52	3
cm438pi64006hoz02m26s2vrw	Private Keys	T1552.004	{CREDENTIAL_ACCESS}	cm438pi63006doz02f0cdcz52	4
cm438pi64006ioz023w68k5we	Cloud Instance Metadata API	T1552.005	{CREDENTIAL_ACCESS}	cm438pi63006doz02f0cdcz52	5
cm438pi64006joz02zg8qfolc	Group Policy Preferences	T1552.006	{CREDENTIAL_ACCESS}	cm438pi63006doz02f0cdcz52	6
cm438pi64006koz02w6zt0s2b	Container API	T1552.007	{CREDENTIAL_ACCESS}	cm438pi63006doz02f0cdcz52	7
cm438pi64006loz025daq9fhm	Chat Messages	T1552.008	{CREDENTIAL_ACCESS}	cm438pi63006doz02f0cdcz52	8
cm438pi6c006moz021ppauwtf	Account Discovery	T1087	{DISCOVERY}	\N	1
cm438pi6c006noz02c20cuexz	Local Account	T1087.001	{DISCOVERY}	cm438pi6c006moz021ppauwtf	1
cm438pi6c006ooz02az8ivf43	Domain Account	T1087.002	{DISCOVERY}	cm438pi6c006moz021ppauwtf	2
cm438pi6c006poz0282ztmw8o	Email Account	T1087.003	{DISCOVERY}	cm438pi6c006moz021ppauwtf	3
cm438pi6c006qoz02dqvhshkb	Cloud Account	T1087.004	{DISCOVERY}	cm438pi6c006moz021ppauwtf	4
cm438pi6j006roz023z2j7796	Application Window Discovery	T1010	{DISCOVERY}	\N	2
cm438pi6n006soz02bn7nq54u	Browser Bookmark Discovery	T1217	{DISCOVERY}	\N	3
cm438pi6r006toz02qlz55omg	Cloud Infrastructure Discovery	T1580	{DISCOVERY}	\N	4
cm438pi6w006uoz02xjqg4fbr	Cloud Service Dashboard	T1538	{DISCOVERY}	\N	5
cm438pi71006voz02f8rrji4v	Cloud Service Discovery	T1526	{DISCOVERY}	\N	6
cm438pi77006woz02bua3k7mw	Cloud Storage Object Discovery	T1619	{DISCOVERY}	\N	7
cm438pi7e006xoz02u31xmm1i	Container and Resource Discovery	T1613	{DISCOVERY}	\N	8
cm438pi7k006yoz026owmoqyk	Device Driver Discovery	T1652	{DISCOVERY}	\N	10
cm438pi7q006zoz02dqufgrh7	Domain Trust Discovery	T1482	{DISCOVERY}	\N	11
cm438pi7w0070oz02jvcsad7b	File and Directory Discovery	T1083	{DISCOVERY}	\N	12
cm438pi840071oz02kf23vnbc	Group Policy Discovery	T1615	{DISCOVERY}	\N	13
cm438pi880072oz02cl90lzct	Log Enumeration	T1654	{DISCOVERY}	\N	14
cm438pi8c0073oz024medaos8	Network Service Discovery	T1046	{DISCOVERY}	\N	15
cm438pi8f0074oz02ppax9st5	Network Share Discovery	T1135	{DISCOVERY}	\N	16
cm438pi8k0075oz020ufgopck	Password Policy Discovery	T1201	{DISCOVERY}	\N	18
cm438pi8p0076oz02z1001pov	Peripheral Device Discovery	T1120	{DISCOVERY}	\N	19
cm438pi8v0077oz027qn6pcxm	Permission Groups Discovery	T1069	{DISCOVERY}	\N	20
cm438pi8v0078oz02k7wruznt	Local Groups	T1069.001	{DISCOVERY}	cm438pi8v0077oz027qn6pcxm	1
cm438pi8v0079oz02cg231zgz	Domain Groups	T1069.002	{DISCOVERY}	cm438pi8v0077oz027qn6pcxm	2
cm438pi8v007aoz02djkkc3yf	Cloud Groups	T1069.003	{DISCOVERY}	cm438pi8v0077oz027qn6pcxm	3
cm438pi94007boz02xhcbgx86	Process Discovery	T1057	{DISCOVERY}	\N	21
cm438pi9a007coz02hd9vp67c	Query Registry	T1012	{DISCOVERY}	\N	22
cm438pi9g007doz02bv2zgxs1	Remote System Discovery	T1018	{DISCOVERY}	\N	23
cm438pi9m007eoz02t9pm9ebd	Software Discovery	T1518	{DISCOVERY}	\N	24
cm438pi9m007foz0228su768b	Security Software Discovery	T1518.001	{DISCOVERY}	cm438pi9m007eoz02t9pm9ebd	1
cm438pi9u007goz0231iap02q	System Information Discovery	T1082	{DISCOVERY}	\N	25
cm438pia2007hoz028a0dvyd1	System Location Discovery	T1614	{DISCOVERY}	\N	26
cm438pia2007ioz02cz935umv	System Language Discovery	T1614.001	{DISCOVERY}	cm438pia2007hoz028a0dvyd1	1
cm438piaa007joz025n00lril	System Network Configuration Discovery	T1016	{DISCOVERY}	\N	27
cm438piab007koz02fk2sw0su	Internet Connection Discovery	T1016.001	{DISCOVERY}	cm438piaa007joz025n00lril	1
cm438piab007loz02la0c9mr9	Wi-Fi Discovery	T1016.002	{DISCOVERY}	cm438piaa007joz025n00lril	2
cm438piah007moz02j7rlnv1v	System Network Connections Discovery	T1049	{DISCOVERY}	\N	28
cm438pian007noz02rvzqtn3c	System Owner/User Discovery	T1033	{DISCOVERY}	\N	29
cm438pias007ooz025do4av30	System Service Discovery	T1007	{DISCOVERY}	\N	30
cm438piax007poz029m9h4a4b	System Time Discovery	T1124	{DISCOVERY}	\N	31
cm438pib4007qoz02us38hvtk	Automated Exfiltration	T1020	{EXFILTRATION}	\N	1
cm438pib4007roz02voiqwjr6	Traffic Duplication	T1020.001	{EXFILTRATION}	cm438pib4007qoz02us38hvtk	1
cm438pibd007soz02nrs6d4fd	Data Transfer Size Limits	T1030	{EXFILTRATION}	\N	2
cm438pibj007toz027zg3h42z	Exfiltration Over Alternative Protocol	T1048	{EXFILTRATION}	\N	3
cm438pibj007uoz02c1ldc6op	Exfiltration Over Symmetric Encrypted Non-C2 Protocol	T1048.001	{EXFILTRATION}	cm438pibj007toz027zg3h42z	1
cm438pibj007voz02vfqqd87i	Exfiltration Over Asymmetric Encrypted Non-C2 Protocol	T1048.002	{EXFILTRATION}	cm438pibj007toz027zg3h42z	2
cm438pibk007woz02jhlaxiuh	Exfiltration Over Unencrypted Non-C2 Protocol	T1048.003	{EXFILTRATION}	cm438pibj007toz027zg3h42z	3
cm438pibt007xoz02ij8o4l4n	Exfiltration Over C2 Channel	T1041	{EXFILTRATION}	\N	4
cm438pibz007yoz02peo9gqtl	Exfiltration Over Other Network Medium	T1011	{EXFILTRATION}	\N	5
cm438pic0007zoz028zqumk55	Exfiltration Over Bluetooth	T1011.001	{EXFILTRATION}	cm438pibz007yoz02peo9gqtl	1
cm438pic70080oz026mx7fl63	Exfiltration Over Physical Medium	T1052	{EXFILTRATION}	\N	6
cm438pic70081oz02d5ye0ciq	Exfiltration Over USB	T1052.001	{EXFILTRATION}	cm438pic70080oz026mx7fl63	1
cm438picf0082oz02e70btmx0	Exfiltration Over Web Service	T1567	{EXFILTRATION}	\N	7
cm438picg0083oz02cj8hizka	Exfiltration to Code Repository	T1567.001	{EXFILTRATION}	cm438picf0082oz02e70btmx0	1
cm438picg0084oz02qsyups9n	Exfiltration to Cloud Storage	T1567.002	{EXFILTRATION}	cm438picf0082oz02e70btmx0	2
cm438picg0085oz02iowkbkmu	Exfiltration to Text Storage Sites	T1567.003	{EXFILTRATION}	cm438picf0082oz02e70btmx0	3
cm438picg0086oz02e3jl5euk	Exfiltration Over Webhook	T1567.004	{EXFILTRATION}	cm438picf0082oz02e70btmx0	4
cm438picn0087oz02yqmnaeky	Scheduled Transfer	T1029	{EXFILTRATION}	\N	8
cm438picu0088oz02kwvdkzmn	Transfer Data to Cloud Account	T1537	{EXFILTRATION}	\N	9
cm438pid00089oz027rzo7c2k	Account Access Removal	T1531	{IMPACT}	\N	1
cm438pid7008aoz02tzmokwsh	Data Destruction	T1485	{IMPACT}	\N	2
cm438pid7008boz02mocm3esl	Lifecycle-Triggered Deletion	T1485.001	{IMPACT}	cm438pid7008aoz02tzmokwsh	1
cm438pidg008coz02fhvct8jo	Data Encrypted for Impact	T1486	{IMPACT}	\N	3
cm438pidk008doz021he2geci	Data Manipulation	T1565	{IMPACT}	\N	4
cm438pidk008eoz027n03e3q3	Stored Data Manipulation	T1565.001	{IMPACT}	cm438pidk008doz021he2geci	1
cm438pidk008foz02rtpr7h6f	Transmitted Data Manipulation	T1565.002	{IMPACT}	cm438pidk008doz021he2geci	2
cm438pidk008goz025siz4b4b	Runtime Data Manipulation	T1565.003	{IMPACT}	cm438pidk008doz021he2geci	3
cm438pidp008hoz02b9cwdflq	Defacement	T1491	{IMPACT}	\N	5
cm438pidp008ioz02v5sq58c7	Internal Defacement	T1491.001	{IMPACT}	cm438pidp008hoz02b9cwdflq	1
cm438pidp008joz02zhyu9teg	External Defacement	T1491.002	{IMPACT}	cm438pidp008hoz02b9cwdflq	2
cm438pidu008koz02t45w2xu4	Disk Wipe	T1561	{IMPACT}	\N	6
cm438pidu008loz027ydoritl	Disk Content Wipe	T1561.001	{IMPACT}	cm438pidu008koz02t45w2xu4	1
cm438pidu008moz02lhxg2sho	Disk Structure Wipe	T1561.002	{IMPACT}	cm438pidu008koz02t45w2xu4	2
cm438pie0008noz02wx3uuguw	Endpoint Denial of Service	T1499	{IMPACT}	\N	7
cm438pie0008ooz02zvmr1iy8	OS Exhaustion Flood	T1499.001	{IMPACT}	cm438pie0008noz02wx3uuguw	1
cm438pie0008poz028x3yyupk	Service Exhaustion Flood	T1499.002	{IMPACT}	cm438pie0008noz02wx3uuguw	2
cm438pie0008qoz02z17fhw05	Application Exhaustion Flood	T1499.003	{IMPACT}	cm438pie0008noz02wx3uuguw	3
cm438pie0008roz0208tyghin	Application or System Exploitation	T1499.004	{IMPACT}	cm438pie0008noz02wx3uuguw	4
cm438pie7008soz02ieyfvd6j	Financial Theft	T1657	{IMPACT}	\N	8
cm438pied008toz020oct29wx	Firmware Corruption	T1495	{IMPACT}	\N	9
cm438piej008uoz02jz3xkhcu	Inhibit System Recovery	T1490	{IMPACT}	\N	10
cm438pieq008voz02nls8dsiv	Network Denial of Service	T1498	{IMPACT}	\N	11
cm438pieq008woz02g4v49g3m	Direct Network Flood	T1498.001	{IMPACT}	cm438pieq008voz02nls8dsiv	1
cm438pieq008xoz02m5zyy9v4	Reflection Amplification	T1498.002	{IMPACT}	cm438pieq008voz02nls8dsiv	2
cm438piez008yoz02dg36ql8x	Resource Hijacking	T1496	{IMPACT}	\N	12
cm438piez008zoz02gav9cbw6	Compute Hijacking	T1496.001	{IMPACT}	cm438piez008yoz02dg36ql8x	1
cm438piez0090oz02vd13dsey	Bandwidth Hijacking	T1496.002	{IMPACT}	cm438piez008yoz02dg36ql8x	2
cm438piez0091oz024vtvbnzp	SMS Pumping	T1496.003	{IMPACT}	cm438piez008yoz02dg36ql8x	3
cm438piez0092oz026ig6znmb	Cloud Service Hijacking	T1496.004	{IMPACT}	cm438piez008yoz02dg36ql8x	4
cm438pif80093oz02hzz6ne0b	Service Stop	T1489	{IMPACT}	\N	13
cm438pifc0094oz02sfnfp616	System Shutdown/Reboot	T1529	{IMPACT}	\N	14
cm438pifh0095oz02x4imwdbb	Exploitation of Remote Services	T1210	{LATERAL_MOVEMENT}	\N	1
cm438pifm0096oz02m1r8lb9w	Internal Spearphishing	T1534	{LATERAL_MOVEMENT}	\N	2
cm438pifr0097oz027lu99vl7	Lateral Tool Transfer	T1570	{LATERAL_MOVEMENT}	\N	3
cm438pifw0098oz02bxd09r66	Remote Services Session Hijacking	T1563	{LATERAL_MOVEMENT}	\N	4
cm438pifw0099oz02x2li929p	SSH Hijacking	T1563.001	{LATERAL_MOVEMENT}	cm438pifw0098oz02bxd09r66	1
cm438pifw009aoz026tnt53j5	RDP Hijacking	T1563.002	{LATERAL_MOVEMENT}	cm438pifw0098oz02bxd09r66	2
cm438pig2009boz02gss9lwfx	Remote Services	T1021	{LATERAL_MOVEMENT}	\N	5
cm438pig2009coz02pv6gkabm	Remote Desktop Protocol	T1021.001	{LATERAL_MOVEMENT}	cm438pig2009boz02gss9lwfx	1
cm438pig3009doz02tibix99s	SMB/Windows Admin Shares	T1021.002	{LATERAL_MOVEMENT}	cm438pig2009boz02gss9lwfx	2
cm438pig3009eoz027f42u8c9	Distributed Component Object Model (DCOM)	T1021.003	{LATERAL_MOVEMENT}	cm438pig2009boz02gss9lwfx	3
cm438pig3009foz02kibz75fg	SSH	T1021.004	{LATERAL_MOVEMENT}	cm438pig2009boz02gss9lwfx	4
cm438pig3009goz02n3tayq3j	VNC	T1021.005	{LATERAL_MOVEMENT}	cm438pig2009boz02gss9lwfx	5
cm438pig3009hoz02424lwfrn	Windows Remote Management	T1021.006	{LATERAL_MOVEMENT}	cm438pig2009boz02gss9lwfx	6
cm438pig3009ioz023pq3py7z	Cloud Services	T1021.007	{LATERAL_MOVEMENT}	cm438pig2009boz02gss9lwfx	7
cm438pig3009joz02trx59uzs	Direct Cloud VM Connections	T1021.008	{LATERAL_MOVEMENT}	cm438pig2009boz02gss9lwfx	8
cm438pig9009koz026s7oqipt	Replication Through Removable Media	T1091	{LATERAL_MOVEMENT,INITIAL_ACCESS}	\N	6
cm438pigd009loz02xxupu7ue	Taint Shared Content	T1080	{LATERAL_MOVEMENT}	\N	8
cm438pigh009moz02bxox85mt	Cloud Administration Command	T1651	{EXECUTION}	\N	1
cm438pigm009noz02i1n38vy6	Command and Scripting Interpreter	T1059	{EXECUTION}	\N	2
cm438pigm009ooz022dt2lw7c	PowerShell	T1059.001	{EXECUTION}	cm438pigm009noz02i1n38vy6	1
cm438pigm009poz02ee8ofht4	AppleScript	T1059.002	{EXECUTION}	cm438pigm009noz02i1n38vy6	2
cm438pigm009qoz029op9ypye	Windows Command Shell	T1059.003	{EXECUTION}	cm438pigm009noz02i1n38vy6	3
cm438pigm009roz027iwlaohn	Unix Shell	T1059.004	{EXECUTION}	cm438pigm009noz02i1n38vy6	4
cm438pigm009soz02xk5bjint	Visual Basic	T1059.005	{EXECUTION}	cm438pigm009noz02i1n38vy6	5
cm438pigm009toz02oqkoyp8j	Python	T1059.006	{EXECUTION}	cm438pigm009noz02i1n38vy6	6
cm438pigm009uoz02627uwznt	JavaScript	T1059.007	{EXECUTION}	cm438pigm009noz02i1n38vy6	7
cm438pigm009voz027jhyovhh	Network Device CLI	T1059.008	{EXECUTION}	cm438pigm009noz02i1n38vy6	8
cm438pigm009woz02g1f0qsjk	Cloud API	T1059.009	{EXECUTION}	cm438pigm009noz02i1n38vy6	9
cm438pigm009xoz02iafpyjfc	AutoHotKey & AutoIT	T1059.010	{EXECUTION}	cm438pigm009noz02i1n38vy6	10
cm438pign009yoz02hg7af4at	Lua	T1059.011	{EXECUTION}	cm438pigm009noz02i1n38vy6	11
cm438pigs009zoz02dcfnd2oq	Container Administration Command	T1609	{EXECUTION}	\N	3
cm438pigy00a0oz02d1dk3bu7	Exploitation for Client Execution	T1203	{EXECUTION}	\N	5
cm438pih200a1oz02y1eybkdw	Inter-Process Communication	T1559	{EXECUTION}	\N	6
cm438pih200a2oz02012t782f	Component Object Model	T1559.001	{EXECUTION}	cm438pih200a1oz02y1eybkdw	1
cm438pih200a3oz0256isucgm	Dynamic Data Exchange	T1559.002	{EXECUTION}	cm438pih200a1oz02y1eybkdw	2
cm438pih200a4oz02pabc5f92	XPC Services	T1559.003	{EXECUTION}	cm438pih200a1oz02y1eybkdw	3
cm438pih800a5oz02qlde3m0q	Native API	T1106	{EXECUTION}	\N	7
cm438pihb00a6oz02gww9kf6s	Serverless Execution	T1648	{EXECUTION}	\N	9
cm438pihf00a7oz02mia07qng	Shared Modules	T1129	{EXECUTION}	\N	10
cm438pihj00a8oz02ofknbuma	Software Deployment Tools	T1072	{EXECUTION,LATERAL_MOVEMENT}	\N	11
cm438pihn00a9oz02g1q9sp06	System Services	T1569	{EXECUTION}	\N	12
cm438pihn00aaoz02nvq5f0qg	Launchctl	T1569.001	{EXECUTION}	cm438pihn00a9oz02g1q9sp06	1
cm438pihn00aboz02q7zikkat	Service Execution	T1569.002	{EXECUTION}	cm438pihn00a9oz02g1q9sp06	2
cm438pihs00acoz02hksed94v	User Execution	T1204	{EXECUTION}	\N	13
cm438pihs00adoz02ux98xfmq	Malicious Link	T1204.001	{EXECUTION}	cm438pihs00acoz02hksed94v	1
cm438pihs00aeoz02m3bao2sv	Malicious File	T1204.002	{EXECUTION}	cm438pihs00acoz02hksed94v	2
cm438pihs00afoz02liyysdq3	Malicious Image	T1204.003	{EXECUTION}	cm438pihs00acoz02hksed94v	3
cm438pihy00agoz02k6vnsfhk	Windows Management Instrumentation	T1047	{EXECUTION}	\N	14
cm438pii200ahoz02ypt4r1h5	Build Image on Host	T1612	{DEFENSE_EVASION}	\N	4
cm438pii600aioz02isr6f1el	Debugger Evasion	T1622	{DEFENSE_EVASION,DISCOVERY}	\N	5
cm438piia00ajoz02nfxc6vj2	Deobfuscate/Decode Files or Information	T1140	{DEFENSE_EVASION}	\N	6
cm438piie00akoz02qnnto5rk	Deploy Container	T1610	{DEFENSE_EVASION,EXECUTION}	\N	7
cm438piih00aloz022uz0d7iv	Direct Volume Access	T1006	{DEFENSE_EVASION}	\N	8
cm438piil00amoz02fpj5hw3j	Execution Guardrails	T1480	{DEFENSE_EVASION}	\N	10
cm438piil00anoz028lows3sx	Environmental Keying	T1480.001	{DEFENSE_EVASION}	cm438piil00amoz02fpj5hw3j	1
cm438piil00aooz020xupagay	Mutual Exclusion	T1480.002	{DEFENSE_EVASION}	cm438piil00amoz02fpj5hw3j	2
cm438piis00apoz02xlkms5us	Exploitation for Defense Evasion	T1211	{DEFENSE_EVASION}	\N	11
cm438piiv00aqoz02wgx0jjx4	File and Directory Permissions Modification	T1222	{DEFENSE_EVASION}	\N	12
cm438piiw00aroz02x7m6a712	Windows File and Directory Permissions Modification	T1222.001	{DEFENSE_EVASION}	cm438piiv00aqoz02wgx0jjx4	1
cm438piiw00asoz02zm4tvu3e	Linux and Mac File and Directory Permissions Modification	T1222.002	{DEFENSE_EVASION}	cm438piiv00aqoz02wgx0jjx4	2
cm438pij100atoz028rnwkw5p	Hide Artifacts	T1564	{DEFENSE_EVASION}	\N	13
cm438pij100auoz02an0vdqg6	Hidden Files and Directories	T1564.001	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	1
cm438pij100avoz02q4vlo6bs	Hidden Users	T1564.002	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	2
cm438pij100awoz02lj38mi05	Hidden Window	T1564.003	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	3
cm438pij100axoz02i1agk7zj	NTFS File Attributes	T1564.004	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	4
cm438pij100ayoz026869mzly	Hidden File System	T1564.005	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	5
cm438pij100azoz02w1yrhj7y	Run Virtual Instance	T1564.006	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	6
cm438pij100b0oz02l06st55y	VBA Stomping	T1564.007	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	7
cm438pij100b1oz02vqjwwawv	Email Hiding Rules	T1564.008	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	8
cm438pij100b2oz02dx9hmq17	Resource Forking	T1564.009	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	9
cm438pij100b3oz02bmvrq5uv	Process Argument Spoofing	T1564.010	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	10
cm438pij100b4oz02gbres08r	Ignore Process Interrupts	T1564.011	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	11
cm438pij100b5oz02rc9wcmea	File/Path Exclusions	T1564.012	{DEFENSE_EVASION}	cm438pij100atoz028rnwkw5p	12
cm438pij700b6oz02pq6zq0op	Hijack Execution Flow	T1574	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	\N	1
cm438pij700b7oz021i37mm4k	DLL Search Order Hijacking	T1574.001	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	1
cm438pij700b8oz02m5hs271s	DLL Side-Loading	T1574.002	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	2
cm438pij700b9oz02flr6j9ma	Dylib Hijacking	T1574.004	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	3
cm438pij700baoz02pw1meqva	Executable Installer File Permissions Weakness	T1574.005	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	4
cm438pij700bboz02neec09tc	Dynamic Linker Hijacking	T1574.006	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	5
cm438pij700bcoz0231ol5oa6	Path Interception by PATH Environment Variable	T1574.007	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	6
cm438pij700bdoz02p45lidmy	Path Interception by Search Order Hijacking	T1574.008	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	7
cm438pij700beoz02twdhpr32	Path Interception by Unquoted Path	T1574.009	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	8
cm438pij800bfoz02foqhhp7p	Services File Permissions Weakness	T1574.010	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	9
cm438pij800bgoz02aksnqf0f	Services Registry Permissions Weakness	T1574.011	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	10
cm438pij800bhoz021n1u4jf3	COR_PROFILER	T1574.012	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	11
cm438pij800bioz02tytguiew	KernelCallbackTable	T1574.013	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	12
cm438pij800bjoz023el0hu7b	AppDomainManager	T1574.014	{DEFENSE_EVASION,PRIVILEGE_ESCALATION}	cm438pij700b6oz02pq6zq0op	13
cm438pijf00bkoz02r7wcchqe	Impair Defenses	T1562	{DEFENSE_EVASION}	\N	2
cm438pijf00bloz02j1215rlr	Disable or Modify Tools	T1562.001	{DEFENSE_EVASION}	cm438pijf00bkoz02r7wcchqe	1
cm438pijf00bmoz02h6yuahmc	Disable Windows Event Logging	T1562.002	{DEFENSE_EVASION}	cm438pijf00bkoz02r7wcchqe	2
cm438pijf00bnoz02qu9u4kpx	Impair Command History Logging	T1562.003	{DEFENSE_EVASION}	cm438pijf00bkoz02r7wcchqe	3
cm438pijf00booz02jaqg2ja2	Disable or Modify System Firewall	T1562.004	{DEFENSE_EVASION}	cm438pijf00bkoz02r7wcchqe	4
cm438pijf00bpoz02bsnclwrk	Indicator Blocking	T1562.006	{DEFENSE_EVASION}	cm438pijf00bkoz02r7wcchqe	5
cm438pijf00bqoz02spksobxq	Disable or Modify Cloud Firewall	T1562.007	{DEFENSE_EVASION}	cm438pijf00bkoz02r7wcchqe	6
cm438pijf00broz02syxdb6ff	Disable or Modify Cloud Logs	T1562.008	{DEFENSE_EVASION}	cm438pijf00bkoz02r7wcchqe	7
cm438pijf00bsoz023xx2yl0n	Safe Mode Boot	T1562.009	{DEFENSE_EVASION}	cm438pijf00bkoz02r7wcchqe	8
cm438pijf00btoz02m4w5s2f1	Downgrade Attack	T1562.010	{DEFENSE_EVASION}	cm438pijf00bkoz02r7wcchqe	9
cm438pijf00buoz02na9e3w4g	Spoof Security Alerting	T1562.011	{DEFENSE_EVASION}	cm438pijf00bkoz02r7wcchqe	10
cm438pijf00bvoz02n452u9j2	Disable or Modify Linux Audit System	T1562.012	{DEFENSE_EVASION}	cm438pijf00bkoz02r7wcchqe	11
cm438pijm00bwoz02517usjm4	Impersonation	T1656	{DEFENSE_EVASION}	\N	1
cm438pijp00bxoz02gkwulysp	Indicator Removal	T1070	{DEFENSE_EVASION}	\N	1
cm438pijp00byoz02kmehy2k4	Clear Windows Event Logs	T1070.001	{DEFENSE_EVASION}	cm438pijp00bxoz02gkwulysp	1
cm438pijp00bzoz02n0krrzan	Clear Linux or Mac System Logs	T1070.002	{DEFENSE_EVASION}	cm438pijp00bxoz02gkwulysp	2
cm438pijp00c0oz02acfxkfl4	Clear Command History	T1070.003	{DEFENSE_EVASION}	cm438pijp00bxoz02gkwulysp	3
cm438pijq00c1oz02y85gngr7	File Deletion	T1070.004	{DEFENSE_EVASION}	cm438pijp00bxoz02gkwulysp	4
cm438pijq00c2oz0293tnuint	Network Share Connection Removal	T1070.005	{DEFENSE_EVASION}	cm438pijp00bxoz02gkwulysp	5
cm438pijq00c3oz02purlzq0i	Timestomp	T1070.006	{DEFENSE_EVASION}	cm438pijp00bxoz02gkwulysp	6
cm438pijq00c4oz02k2xd0gq2	Clear Network Connection History and Configurations	T1070.007	{DEFENSE_EVASION}	cm438pijp00bxoz02gkwulysp	7
cm438pijq00c5oz02anh00ub1	Clear Mailbox Data	T1070.008	{DEFENSE_EVASION}	cm438pijp00bxoz02gkwulysp	8
cm438pijq00c6oz023yoww2ix	Clear Persistence	T1070.009	{DEFENSE_EVASION}	cm438pijp00bxoz02gkwulysp	9
cm438pijq00c7oz02rru7njv1	Relocate Malware	T1070.010	{DEFENSE_EVASION}	cm438pijp00bxoz02gkwulysp	10
cm438pijw00c8oz025h5dj64j	Indirect Command Execution	T1202	{DEFENSE_EVASION}	\N	1
cm438pik000c9oz02x3n99x6u	Masquerading	T1036	{DEFENSE_EVASION}	\N	2
cm438pik000caoz02hijfomol	Invalid Code Signature	T1036.001	{DEFENSE_EVASION}	cm438pik000c9oz02x3n99x6u	1
cm438pik000cboz024wexpzcs	Right-to-Left Override	T1036.002	{DEFENSE_EVASION}	cm438pik000c9oz02x3n99x6u	2
cm438pik000ccoz02wh9saxyu	Rename System Utilities	T1036.003	{DEFENSE_EVASION}	cm438pik000c9oz02x3n99x6u	3
cm438pik000cdoz022olzg8a0	Masquerade Task or Service	T1036.004	{DEFENSE_EVASION}	cm438pik000c9oz02x3n99x6u	4
cm438pik000ceoz02j6l9fxrf	Match Legitimate Name or Location	T1036.005	{DEFENSE_EVASION}	cm438pik000c9oz02x3n99x6u	5
cm438pik000cfoz02nl9ok39q	Space after Filename	T1036.006	{DEFENSE_EVASION}	cm438pik000c9oz02x3n99x6u	6
cm438pik000cgoz02vtslh3lx	Double File Extension	T1036.007	{DEFENSE_EVASION}	cm438pik000c9oz02x3n99x6u	7
cm438pik000choz025y7x02bw	Masquerade File Type	T1036.008	{DEFENSE_EVASION}	cm438pik000c9oz02x3n99x6u	8
cm438pik000cioz02cqbya3yx	Break Process Trees	T1036.009	{DEFENSE_EVASION}	cm438pik000c9oz02x3n99x6u	9
cm438pik000cjoz02syr2yv03	Masquerade Account Name	T1036.010	{DEFENSE_EVASION}	cm438pik000c9oz02x3n99x6u	10
cm438pik600ckoz026gmtiri7	Modify Cloud Compute Infrastructure	T1578	{DEFENSE_EVASION}	\N	4
cm438pik600cloz02re05055t	Create Snapshot	T1578.001	{DEFENSE_EVASION}	cm438pik600ckoz026gmtiri7	1
cm438pik600cmoz02zofrqieb	Create Cloud Instance	T1578.002	{DEFENSE_EVASION}	cm438pik600ckoz026gmtiri7	2
cm438pik600cnoz02fm12qhal	Delete Cloud Instance	T1578.003	{DEFENSE_EVASION}	cm438pik600ckoz026gmtiri7	3
cm438pik600cooz0259bvz6pp	Revert Cloud Instance	T1578.004	{DEFENSE_EVASION}	cm438pik600ckoz026gmtiri7	4
cm438pik600cpoz02esvd7i9j	Modify Cloud Compute Configurations	T1578.005	{DEFENSE_EVASION}	cm438pik600ckoz026gmtiri7	5
cm438pikb00cqoz02vicqy4jq	Modify Cloud Resource Hierarchy	T1666	{DEFENSE_EVASION}	\N	1
cm438pikg00croz02bcmwvkp4	Modify Registry	T1112	{DEFENSE_EVASION}	\N	2
cm438pikm00csoz02qvsahgur	Modify System Image	T1601	{DEFENSE_EVASION}	\N	3
cm438pikm00ctoz02m4tpwzw1	Patch System Image	T1601.001	{DEFENSE_EVASION}	cm438pikm00csoz02qvsahgur	1
cm438pikm00cuoz02jsu7fy8v	Downgrade System Image	T1601.002	{DEFENSE_EVASION}	cm438pikm00csoz02qvsahgur	2
cm438piks00cvoz02zdetsqxn	Network Boundary Bridging	T1599	{DEFENSE_EVASION}	\N	4
cm438piks00cwoz02dj1j1zk6	Network Address Translation Traversal	T1599.001	{DEFENSE_EVASION}	cm438piks00cvoz02zdetsqxn	1
cm438pikx00cxoz02pgaon3rp	Obfuscated Files or Information	T1027	{DEFENSE_EVASION}	\N	5
cm438pikx00cyoz02omwo7zjg	Binary Padding	T1027.001	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	1
cm438pikx00czoz02np9uts4n	Software Packing	T1027.002	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	2
cm438pikx00d0oz02e63i7zql	Steganography	T1027.003	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	3
cm438pikx00d1oz029iv5gd8l	Compile After Delivery	T1027.004	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	4
cm438pikx00d2oz0207of6nav	Indicator Removal from Tools	T1027.005	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	5
cm438pikx00d3oz02c8aabeon	HTML Smuggling	T1027.006	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	6
cm438pikx00d4oz02giivzq90	Dynamic API Resolution	T1027.007	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	7
cm438pikx00d5oz02exagcnz0	Stripped Payloads	T1027.008	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	8
cm438pikx00d6oz02mgs3pdzl	Embedded Payloads	T1027.009	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	9
cm438pikx00d7oz025ecec4x7	Command Obfuscation	T1027.010	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	10
cm438pikx00d8oz02wq4mxa6b	Fileless Storage	T1027.011	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	11
cm438pikx00d9oz024eh2a55h	LNK Icon Smuggling	T1027.012	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	12
cm438pikx00daoz02amun4nwb	Encrypted/Encoded File	T1027.013	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	13
cm438pikx00dboz02wp6vbtmd	Polymorphic Code	T1027.014	{DEFENSE_EVASION}	cm438pikx00cxoz02pgaon3rp	14
cm438pil400dcoz02pgii5htl	Plist File Modification	T1647	{DEFENSE_EVASION}	\N	6
cm438pil700ddoz02q1x6k1pa	Reflective Code Loading	T1620	{DEFENSE_EVASION}	\N	1
cm438pila00deoz02ousual97	Rogue Domain Controller	T1207	{DEFENSE_EVASION}	\N	2
cm438pile00dfoz02pzg3v7p7	Rootkit	T1014	{DEFENSE_EVASION}	\N	3
cm438pili00dgoz02jwqekofr	Subvert Trust Controls	T1553	{DEFENSE_EVASION}	\N	4
cm438pili00dhoz023jyj6ez6	Gatekeeper Bypass	T1553.001	{DEFENSE_EVASION}	cm438pili00dgoz02jwqekofr	1
cm438pili00dioz02an4l9ajx	Code Signing	T1553.002	{DEFENSE_EVASION}	cm438pili00dgoz02jwqekofr	2
cm438pili00djoz0262b33erk	SIP and Trust Provider Hijacking	T1553.003	{DEFENSE_EVASION}	cm438pili00dgoz02jwqekofr	3
cm438pili00dkoz02ukiq01rf	Install Root Certificate	T1553.004	{DEFENSE_EVASION}	cm438pili00dgoz02jwqekofr	4
cm438pili00dloz02gj59ywgp	Mark-of-the-Web Bypass	T1553.005	{DEFENSE_EVASION}	cm438pili00dgoz02jwqekofr	5
cm438pili00dmoz020s2207u3	Code Signing Policy Modification	T1553.006	{DEFENSE_EVASION}	cm438pili00dgoz02jwqekofr	6
cm438piln00dnoz02yr5ir2az	System Binary Proxy Execution	T1218	{DEFENSE_EVASION}	\N	5
cm438pilo00dooz02foaba9mp	Compiled HTML File	T1218.001	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	1
cm438pilo00dpoz02owarx0en	Control Panel	T1218.002	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	2
cm438pilo00dqoz02t449kjcq	CMSTP	T1218.003	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	3
cm438pilo00droz02wvo1441h	InstallUtil	T1218.004	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	4
cm438pilo00dsoz02xaj4t1pa	Mshta	T1218.005	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	5
cm438pilo00dtoz02cijevnpf	Msiexec	T1218.007	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	6
cm438pilo00duoz02c3ddtodq	Odbcconf	T1218.008	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	7
cm438pilo00dvoz02xqhacxz2	Regsvcs/Regasm	T1218.009	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	8
cm438pilo00dwoz025krn9xt5	Regsvr32	T1218.010	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	9
cm438pilo00dxoz027i76reqc	Rundll32	T1218.011	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	10
cm438pilo00dyoz022azyivcp	Verclsid	T1218.012	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	11
cm438pilo00dzoz02v1xfpgo5	Mavinject	T1218.013	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	12
cm438pilo00e0oz0241cxpe6m	MMC	T1218.014	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	13
cm438pilo00e1oz0239ua7tlo	Electron Applications	T1218.015	{DEFENSE_EVASION}	cm438piln00dnoz02yr5ir2az	14
cm438pilu00e2oz02wtjadl4c	System Script Proxy Execution	T1216	{DEFENSE_EVASION}	\N	6
cm438pilu00e3oz02c4zpyn57	PubPrn	T1216.001	{DEFENSE_EVASION}	cm438pilu00e2oz02wtjadl4c	1
cm438pilu00e4oz02pebo19p9	SyncAppvPublishingServer	T1216.002	{DEFENSE_EVASION}	cm438pilu00e2oz02wtjadl4c	2
cm438pilz00e5oz02z2uhzv8q	Template Injection	T1221	{DEFENSE_EVASION}	\N	7
cm438pim400e6oz02mt4n72iq	Trusted Developer Utilities Proxy Execution	T1127	{DEFENSE_EVASION}	\N	2
cm438pim400e7oz02h1gznm2r	MSBuild	T1127.001	{DEFENSE_EVASION}	cm438pim400e6oz02mt4n72iq	1
cm438pim400e8oz02g7eelw36	ClickOnce	T1127.002	{DEFENSE_EVASION}	cm438pim400e6oz02mt4n72iq	2
cm438pima00e9oz02elr68td6	Unused/Unsupported Cloud Regions	T1535	{DEFENSE_EVASION}	\N	3
cm438pimf00eaoz02ouy6lost	Use Alternate Authentication Material	T1550	{DEFENSE_EVASION,LATERAL_MOVEMENT}	\N	4
cm438pimf00eboz02sxr79wz0	Application Access Token	T1550.001	{DEFENSE_EVASION,LATERAL_MOVEMENT}	cm438pimf00eaoz02ouy6lost	1
cm438pimf00ecoz02n55phbja	Pass the Hash	T1550.002	{DEFENSE_EVASION,LATERAL_MOVEMENT}	cm438pimf00eaoz02ouy6lost	2
cm438pimf00edoz02rqd3pbgv	Pass the Ticket	T1550.003	{DEFENSE_EVASION,LATERAL_MOVEMENT}	cm438pimf00eaoz02ouy6lost	3
cm438pimf00eeoz02ww7fuk0s	Web Session Cookie	T1550.004	{DEFENSE_EVASION,LATERAL_MOVEMENT}	cm438pimf00eaoz02ouy6lost	4
cm438pimk00efoz022i31br8r	Valid Accounts	T1078	{DEFENSE_EVASION,PRIVILEGE_ESCALATION,PERSISTENCE,INITIAL_ACCESS}	\N	5
cm438pimk00egoz022wfvvdrx	Default Accounts	T1078.001	{DEFENSE_EVASION,PRIVILEGE_ESCALATION,PERSISTENCE,INITIAL_ACCESS}	cm438pimk00efoz022i31br8r	1
cm438pimk00ehoz0221pcgho0	Domain Accounts	T1078.002	{DEFENSE_EVASION,PRIVILEGE_ESCALATION,PERSISTENCE,INITIAL_ACCESS}	cm438pimk00efoz022i31br8r	2
cm438pimk00eioz02vfuacc43	Local Accounts	T1078.003	{DEFENSE_EVASION,PRIVILEGE_ESCALATION,PERSISTENCE,INITIAL_ACCESS}	cm438pimk00efoz022i31br8r	3
cm438pimk00ejoz02f61iik1z	Cloud Accounts	T1078.004	{DEFENSE_EVASION,PRIVILEGE_ESCALATION,PERSISTENCE,INITIAL_ACCESS}	cm438pimk00efoz022i31br8r	4
cm438pimq00ekoz02f4ymywjw	Virtualization/Sandbox Evasion	T1497	{DEFENSE_EVASION,DISCOVERY}	\N	6
cm438pimq00eloz02v3byhlrw	System Checks	T1497.001	{DEFENSE_EVASION,DISCOVERY}	cm438pimq00ekoz02f4ymywjw	1
cm438pimq00emoz02zld0gedn	User Activity Based Checks	T1497.002	{DEFENSE_EVASION,DISCOVERY}	cm438pimq00ekoz02f4ymywjw	2
cm438pimq00enoz023w944t2g	Time Based Evasion	T1497.003	{DEFENSE_EVASION,DISCOVERY}	cm438pimq00ekoz02f4ymywjw	3
cm438pimx00eooz026jolhgql	Weaken Encryption	T1600	{DEFENSE_EVASION}	\N	7
cm438pimx00epoz022oqary6w	Reduce Key Space	T1600.001	{DEFENSE_EVASION}	cm438pimx00eooz026jolhgql	1
cm438pimx00eqoz02nmpabx5r	Disable Crypto Hardware	T1600.002	{DEFENSE_EVASION}	cm438pimx00eooz026jolhgql	2
cm438pin100eroz02k8knh4in	XSL Script Processing	T1220	{DEFENSE_EVASION}	\N	8
cm438pin600esoz02efc3oh4k	Account Manipulation	T1098	{PERSISTENCE,PRIVILEGE_ESCALATION}	\N	1
cm438pin600etoz02rnkmbj15	Additional Cloud Credentials	T1098.001	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pin600esoz02efc3oh4k	1
cm438pin600euoz02trtsqrw7	Additional Email Delegate Permissions	T1098.002	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pin600esoz02efc3oh4k	2
cm438pin600evoz028u556r0m	Additional Cloud Roles	T1098.003	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pin600esoz02efc3oh4k	3
cm438pin600ewoz0280lf3elq	SSH Authorized Keys	T1098.004	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pin600esoz02efc3oh4k	4
cm438pin600exoz02fn0vojld	Device Registration	T1098.005	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pin600esoz02efc3oh4k	5
cm438pin600eyoz02b6xqtvze	Additional Container Cluster Roles	T1098.006	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pin600esoz02efc3oh4k	6
cm438pin700ezoz02xaagahqc	Additional Local or Domain Groups	T1098.007	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pin600esoz02efc3oh4k	7
cm438pinc00f0oz02v9pqajf2	BITS Jobs	T1197	{PERSISTENCE,DEFENSE_EVASION}	\N	2
cm438ping00f1oz02gjbxfyzs	Boot or Logon Autostart Execution	T1547	{PERSISTENCE,PRIVILEGE_ESCALATION}	\N	3
cm438pinh00f2oz02lana13y5	Registry Run Keys / Startup Folder	T1547.001	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	1
cm438pinh00f3oz02agqruwn9	Authentication Package	T1547.002	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	2
cm438pinh00f4oz02z0k3agtb	Time Providers	T1547.003	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	3
cm438pinh00f5oz02wc6cxwrz	Winlogon Helper DLL	T1547.004	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	4
cm438pinh00f6oz02qe4kt6uy	Security Support Provider	T1547.005	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	5
cm438pinh00f7oz02uun80h57	Kernel Modules and Extensions	T1547.006	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	6
cm438pinh00f8oz02gpfjvl33	Re-opened Applications	T1547.007	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	7
cm438pinh00f9oz02iznptaqy	LSASS Driver	T1547.008	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	8
cm438pinh00faoz02uym7mzjd	Shortcut Modification	T1547.009	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	9
cm438pinh00fboz021tas71lw	Port Monitors	T1547.010	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	10
cm438pinh00fcoz025n7p712f	Print Processors	T1547.012	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	12
cm438pinh00fdoz02zceascmn	XDG Autostart Entries	T1547.013	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	13
cm438pinh00feoz02ymhx0ula	Active Setup	T1547.014	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	14
cm438pinh00ffoz02yzkou49r	Login Items	T1547.015	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438ping00f1oz02gjbxfyzs	15
cm438pinn00fgoz02c3504gz1	Boot or Logon Initialization Scripts	T1037	{PERSISTENCE,PRIVILEGE_ESCALATION}	\N	4
cm438pinn00fhoz02alxwrogr	Logon Script (Windows)	T1037.001	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pinn00fgoz02c3504gz1	1
cm438pinn00fioz02skq6t14s	Login Hook	T1037.002	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pinn00fgoz02c3504gz1	2
cm438pinn00fjoz029bkj974c	Network Logon Script	T1037.003	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pinn00fgoz02c3504gz1	3
cm438pinn00fkoz02bveabcfd	Tactic.PERSISTENCE	T1037.004	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pinn00fgoz02c3504gz1	4
cm438pinn00floz02pgcz5i6u	Startup Items	T1037.005	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pinn00fgoz02c3504gz1	5
cm438pint00fmoz02ism0cw0k	Browser Extensions	T1176	{PERSISTENCE}	\N	5
cm438pinw00fnoz02om9jm0n1	Compromise Client Software Binary	T1554	{PERSISTENCE}	\N	6
cm438pio100fooz029ymgk1wu	Create Account	T1136	{PERSISTENCE}	\N	7
cm438pio100fpoz02kalx9vc4	Local Account	T1136.001	{PERSISTENCE}	cm438pio100fooz029ymgk1wu	1
cm438pio100fqoz02stop6288	Domain Account	T1136.002	{PERSISTENCE}	cm438pio100fooz029ymgk1wu	2
cm438pio100froz02fp258snz	Cloud Account	T1136.003	{PERSISTENCE}	cm438pio100fooz029ymgk1wu	3
cm438pio700fsoz02mc7i8wes	Create or Modify System Process	T1543	{PERSISTENCE,PRIVILEGE_ESCALATION}	\N	8
cm438pio700ftoz02mjczq869	Launch Agent	T1543.001	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pio700fsoz02mc7i8wes	1
cm438pio700fuoz02ja7qb30b	Systemd Service	T1543.002	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pio700fsoz02mc7i8wes	2
cm438pio700fvoz02sqpfcu09	Windows Service	T1543.003	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pio700fsoz02mc7i8wes	3
cm438pio700fwoz02xdo3r53a	Launch Daemon	T1543.004	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pio700fsoz02mc7i8wes	4
cm438pio700fxoz027gtrwzk7	Container Service	T1543.005	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pio700fsoz02mc7i8wes	5
cm438pioc00fyoz02fp7dyasb	Event Triggered Execution	T1546	{PERSISTENCE,PRIVILEGE_ESCALATION}	\N	9
cm438piod00fzoz02bs1of4vn	Change Default File Association	T1546.001	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	1
cm438piod00g0oz02p2iupzjv	Screensaver	T1546.002	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	2
cm438piod00g1oz02if5el0p7	Windows Management Instrumentation Event Subscription	T1546.003	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	3
cm438piod00g2oz02uiiby147	Unix Shell Configuration Modification	T1546.004	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	4
cm438piod00g3oz02wykt8i6e	Trap	T1546.005	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	5
cm438piod00g4oz02tem5113o	LC_LOAD_DYLIB Addition	T1546.006	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	6
cm438piod00g5oz02fuydfegv	Netsh Helper DLL	T1546.007	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	7
cm438piod00g6oz020vjhfnux	Accessibility Features	T1546.008	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	8
cm438piod00g7oz02lyu42pyt	AppCert DLLs	T1546.009	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	9
cm438piod00g8oz02finmp27q	AppInit DLLs	T1546.010	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	10
cm438piod00g9oz027s05woz7	Application Shimming	T1546.011	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	11
cm438piod00gaoz02mco5qo5t	Image File Execution Options Injection	T1546.012	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	12
cm438piod00gboz02x40ywjhj	PowerShell Profile	T1546.013	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	13
cm438piod00gcoz02hwgedw0l	Emond	T1546.014	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	14
cm438piod00gdoz02g94zle7x	Component Object Model Hijacking	T1546.015	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	15
cm438piod00geoz02b39fbiv5	Installer Packages	T1546.016	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	16
cm438piod00gfoz024m43u02e	Udev Rules	T1546.017	{PERSISTENCE,PRIVILEGE_ESCALATION}	cm438pioc00fyoz02fp7dyasb	17
cm438piol00ggoz02890lfpct	External Remote Services	T1133	{PERSISTENCE,INITIAL_ACCESS}	\N	10
cm438pipe00gvoz02mdl6phyc	Implant Internal Image	T1525	{PERSISTENCE}	\N	12
cm438pipj00gwoz02gi5lzwjz	Modify Authentication Process	T1556	{PERSISTENCE,CREDENTIAL_ACCESS,DEFENSE_EVASION}	\N	12
cm438pipj00gxoz02prqcr6st	Domain Controller Authentication	T1556.001	{PERSISTENCE,CREDENTIAL_ACCESS,DEFENSE_EVASION}	cm438pipj00gwoz02gi5lzwjz	1
cm438pipj00gyoz028bw383bp	Password Filter DLL	T1556.002	{PERSISTENCE,CREDENTIAL_ACCESS,DEFENSE_EVASION}	cm438pipj00gwoz02gi5lzwjz	2
cm438pipj00gzoz02dguoww5v	Pluggable Authentication Modules	T1556.003	{PERSISTENCE,CREDENTIAL_ACCESS,DEFENSE_EVASION}	cm438pipj00gwoz02gi5lzwjz	3
cm438pipj00h0oz02invnlkm1	Network Device Authentication	T1556.004	{PERSISTENCE,CREDENTIAL_ACCESS,DEFENSE_EVASION}	cm438pipj00gwoz02gi5lzwjz	4
cm438pipj00h1oz02l92u3mvp	Reversible Encryption	T1556.005	{PERSISTENCE,CREDENTIAL_ACCESS,DEFENSE_EVASION}	cm438pipj00gwoz02gi5lzwjz	5
cm438pipj00h2oz021uj7vklg	Multi-Factor Authentication	T1556.006	{PERSISTENCE,CREDENTIAL_ACCESS,DEFENSE_EVASION}	cm438pipj00gwoz02gi5lzwjz	6
cm438pipj00h3oz02zh9ab6fg	Hybrid Identity	T1556.007	{PERSISTENCE,CREDENTIAL_ACCESS,DEFENSE_EVASION}	cm438pipj00gwoz02gi5lzwjz	7
cm438pipj00h4oz023g8yk8er	Network Provider DLL	T1556.008	{PERSISTENCE,CREDENTIAL_ACCESS,DEFENSE_EVASION}	cm438pipj00gwoz02gi5lzwjz	8
cm438pipk00h5oz02npxq80zp	Conditional Access Policies	T1556.009	{PERSISTENCE,CREDENTIAL_ACCESS,DEFENSE_EVASION}	cm438pipj00gwoz02gi5lzwjz	9
cm438pipn00h6oz0264yl5snc	Office Application Startup	T1137	{PERSISTENCE}	\N	13
cm438pipn00h7oz025u4yf78r	Office Template Macros	T1137.001	{PERSISTENCE}	cm438pipn00h6oz0264yl5snc	1
cm438pipn00h8oz025f0s5mvh	Office Test	T1137.002	{PERSISTENCE}	cm438pipn00h6oz0264yl5snc	2
cm438pipn00h9oz024eu6zcr3	Outlook Forms	T1137.003	{PERSISTENCE}	cm438pipn00h6oz0264yl5snc	3
cm438pipn00haoz02ik1jrc6x	Outlook Home Page	T1137.004	{PERSISTENCE}	cm438pipn00h6oz0264yl5snc	4
cm438pipn00hboz02z1b7grt2	Outlook Rules	T1137.005	{PERSISTENCE}	cm438pipn00h6oz0264yl5snc	5
cm438pipn00hcoz02j5yyth6i	Add-ins	T1137.006	{PERSISTENCE}	cm438pipn00h6oz0264yl5snc	6
cm438pipr00hdoz02eykfw3k9	Power Settings	T1653	{PERSISTENCE}	\N	15
cm438pipu00heoz02lrj51qvk	Pre-OS Boot	T1542	{PERSISTENCE,DEFENSE_EVASION}	\N	14
cm438pipu00hfoz02n24llg0n	System Firmware	T1542.001	{PERSISTENCE,DEFENSE_EVASION}	cm438pipu00heoz02lrj51qvk	1
cm438pipu00hgoz02p4xi9mmd	Component Firmware	T1542.002	{PERSISTENCE,DEFENSE_EVASION}	cm438pipu00heoz02lrj51qvk	2
cm438pipu00hhoz02ggg2xx1e	Bootkit	T1542.003	{PERSISTENCE,DEFENSE_EVASION}	cm438pipu00heoz02lrj51qvk	3
cm438pipu00hioz02od8ifot0	ROMMONkit	T1542.004	{PERSISTENCE,DEFENSE_EVASION}	cm438pipu00heoz02lrj51qvk	4
cm438pipu00hjoz02z1txacto	TFTP Boot	T1542.005	{PERSISTENCE,DEFENSE_EVASION}	cm438pipu00heoz02lrj51qvk	5
cm438pipy00hkoz029dubemmp	Scheduled Task/Job	T1053	{PERSISTENCE,PRIVILEGE_ESCALATION,EXECUTION}	\N	15
cm438pipy00hloz02ib4gjhip	At	T1053.002	{PERSISTENCE,PRIVILEGE_ESCALATION,EXECUTION}	cm438pipy00hkoz029dubemmp	1
cm438pipy00hmoz02l785s2sr	Cron	T1053.003	{PERSISTENCE,PRIVILEGE_ESCALATION,EXECUTION}	cm438pipy00hkoz029dubemmp	2
cm438pipy00hnoz02bfgulelz	Scheduled Task	T1053.005	{PERSISTENCE,PRIVILEGE_ESCALATION,EXECUTION}	cm438pipy00hkoz029dubemmp	3
cm438pipy00hooz02bzfpkcj7	Systemd Timers	T1053.006	{PERSISTENCE,PRIVILEGE_ESCALATION,EXECUTION}	cm438pipy00hkoz029dubemmp	4
cm438pipy00hpoz021325pvhf	Container Orchestration Job	T1053.007	{PERSISTENCE,PRIVILEGE_ESCALATION,EXECUTION}	cm438pipy00hkoz029dubemmp	5
cm438piq300hqoz02cq2mb0tv	Server Software Component	T1505	{PERSISTENCE}	\N	16
cm438piq300hroz02alfaum7m	SQL Stored Procedures	T1505.001	{PERSISTENCE}	cm438piq300hqoz02cq2mb0tv	1
cm438piq300hsoz02gblzxp5b	Transport Agent	T1505.002	{PERSISTENCE}	cm438piq300hqoz02cq2mb0tv	2
cm438piq300htoz02swl02ynj	Web Shell	T1505.003	{PERSISTENCE}	cm438piq300hqoz02cq2mb0tv	3
cm438piq300huoz02y8kgrjah	IIS Components	T1505.004	{PERSISTENCE}	cm438piq300hqoz02cq2mb0tv	4
cm438piq300hvoz024qjvn51w	Terminal Services DLL	T1505.005	{PERSISTENCE}	cm438piq300hqoz02cq2mb0tv	5
cm438piq800hwoz02qubbysbr	Traffic Signaling	T1205	{PERSISTENCE,COMMAND_AND_CONTROL,DEFENSE_EVASION}	\N	17
cm438piq800hxoz025z7fivuu	Port Knocking	T1205.001	{PERSISTENCE,COMMAND_AND_CONTROL,DEFENSE_EVASION}	cm438piq800hwoz02qubbysbr	1
cm438piq800hyoz02mvzby3yh	Socket Filters	T1205.002	{PERSISTENCE,COMMAND_AND_CONTROL,DEFENSE_EVASION}	cm438piq800hwoz02qubbysbr	2
cm438piqd00hzoz027kgymbsr	Abuse Elevation Control Mechanism	T1548	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	\N	1
cm438piqd00i0oz02mh24srpb	Setuid and Setgid	T1548.001	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	cm438piqd00hzoz027kgymbsr	1
cm438piqd00i1oz02vswctakk	Bypass User Account Control	T1548.002	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	cm438piqd00hzoz027kgymbsr	2
cm438piqd00i2oz02dy45hfqq	Sudo and Sudo Caching	T1548.003	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	cm438piqd00hzoz027kgymbsr	3
cm438piqd00i3oz023eqteolv	Elevated Execution with Prompt	T1548.004	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	cm438piqd00hzoz027kgymbsr	4
cm438piqd00i4oz0267sbda6p	Temporary Elevated Cloud Access	T1548.005	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	cm438piqd00hzoz027kgymbsr	5
cm438piqd00i5oz02vfeyygq4	TCC Manipulation	T1548.006	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	cm438piqd00hzoz027kgymbsr	6
cm438piqg00i6oz02vn10lv4m	Access Token Manipulation	T1134	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	\N	2
cm438piqg00i7oz02h8xozyll	Token Impersonation/Theft	T1134.001	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	cm438piqg00i6oz02vn10lv4m	1
cm438piqg00i8oz02tj74zihh	Create Process with Token	T1134.002	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	cm438piqg00i6oz02vn10lv4m	2
cm438piqg00i9oz02c3qydcjh	Make and Impersonate Token	T1134.003	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	cm438piqg00i6oz02vn10lv4m	3
cm438piqg00iaoz0240crvv5p	Parent PID Spoofing	T1134.004	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	cm438piqg00i6oz02vn10lv4m	4
cm438piqg00iboz02dof14xmt	SID-History Injection	T1134.005	{PRIVILEGE_ESCALATION,PRIVILEGE_ESCALATION}	cm438piqg00i6oz02vn10lv4m	5
cm438piqj00icoz02rvqlz1ld	Domain or Tenant Policy Modification	T1484	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	\N	3
cm438piqj00idoz02v9tvx0r7	Group Policy Modification	T1484.001	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqj00icoz02rvqlz1ld	1
cm438piqj00ieoz02lsm8z6dx	Trust Modification	T1484.002	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqj00icoz02rvqlz1ld	2
cm438piqn00ifoz02b0b3vg69	Escape to Host	T1611	{PRIVILEGE_ESCALATION}	\N	4
cm438piqq00igoz0250abkjn9	Exploitation for Privilege Escalation	T1068	{PRIVILEGE_ESCALATION}	\N	1
cm438piqs00ihoz027ihe85xj	Process Injection	T1055	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	\N	3
cm438piqs00iioz02a22c46wx	Dynamic-link Library Injection	T1055.001	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	1
cm438piqs00ijoz02ogvmwo5n	Portable Executable Injection	T1055.002	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	2
cm438piqs00ikoz02149r5evd	Thread Execution Hijacking	T1055.003	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	3
cm438piqs00iloz025telk17m	Asynchronous Procedure Call	T1055.004	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	4
cm438piqs00imoz02kg85mkjd	Thread Local Storage	T1055.005	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	5
cm438piqs00inoz02ircyo886	Ptrace System Calls	T1055.008	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	6
cm438piqs00iooz02howfoelr	Proc Memory	T1055.009	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	7
cm438piqs00ipoz02o9rsq8a5	Extra Window Memory Injection	T1055.011	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	8
cm438piqs00iqoz02jlaeg4xl	Process Hollowing	T1055.012	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	9
cm438piqs00iroz02ci5tq0xn	Process Doppelgänging	T1055.013	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	10
cm438piqs00isoz022ezdr88w	VDSO Hijacking	T1055.014	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	11
cm438piqs00itoz02f7kdjlhk	ListPlanting	T1055.015	{PRIVILEGE_ESCALATION,DEFENSE_EVASION}	cm438piqs00ihoz027ihe85xj	12
\.


--
-- Data for Name: ThreatActor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ThreatActor" (id, name, notes, "createdAt", "updatedAt") FROM stdin;
cm438t3ap0008ozvyeebesd84	Test		2024-11-29 21:15:32.208	2024-11-29 21:15:32.208
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, password, name, "resetToken", "updatedAt", "createdAt") FROM stdin;
7b580e88-f44d-4f77-98ee-92c0e1b8d32a	ra@bo.ch	$2a$10$6qRB2erzh5Q7AX5l5hgDs..4yZwHzYtVPJrLpDI0q1YlVWzO8Hdq6	Ralf Boltshauser	\N	2024-11-29 21:14:15.542	2024-11-29 21:14:15.542
\.


--
-- Data for Name: _AlertIOCs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_AlertIOCs" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _AssetAlerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_AssetAlerts" ("A", "B") FROM stdin;
cm438s32g0002ozvy1qmyf8mg	cm438rwlx0000ozvyypcjogif
cm43ykanx0000ozsqhha2sb36	cm438rwlx0000ozvyypcjogif
\.


--
-- Data for Name: _ThreatActorTechniques; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_ThreatActorTechniques" ("A", "B") FROM stdin;
cm438phx8000aoz02veae9q5o	cm438t3ap0008ozvyeebesd84
\.


--
-- Name: AlertCategory AlertCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AlertCategory"
    ADD CONSTRAINT "AlertCategory_pkey" PRIMARY KEY (id);


--
-- Name: Alert Alert_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Alert"
    ADD CONSTRAINT "Alert_pkey" PRIMARY KEY (id);


--
-- Name: AssetUptime AssetUptime_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssetUptime"
    ADD CONSTRAINT "AssetUptime_pkey" PRIMARY KEY (id);


--
-- Name: Asset Asset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_pkey" PRIMARY KEY (id);


--
-- Name: AttackChain AttackChain_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AttackChain"
    ADD CONSTRAINT "AttackChain_pkey" PRIMARY KEY (id);


--
-- Name: Event Event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_pkey" PRIMARY KEY (id);


--
-- Name: IOC IOC_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IOC"
    ADD CONSTRAINT "IOC_pkey" PRIMARY KEY (id);


--
-- Name: Network Network_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Network"
    ADD CONSTRAINT "Network_pkey" PRIMARY KEY (id);


--
-- Name: ResponseAction ResponseAction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResponseAction"
    ADD CONSTRAINT "ResponseAction_pkey" PRIMARY KEY (id);


--
-- Name: Technique Technique_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Technique"
    ADD CONSTRAINT "Technique_pkey" PRIMARY KEY (id);


--
-- Name: ThreatActor ThreatActor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ThreatActor"
    ADD CONSTRAINT "ThreatActor_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _AlertIOCs _AlertIOCs_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_AlertIOCs"
    ADD CONSTRAINT "_AlertIOCs_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _AssetAlerts _AssetAlerts_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_AssetAlerts"
    ADD CONSTRAINT "_AssetAlerts_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _ThreatActorTechniques _ThreatActorTechniques_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_ThreatActorTechniques"
    ADD CONSTRAINT "_ThreatActorTechniques_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: AlertCategory_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AlertCategory_name_key" ON public."AlertCategory" USING btree (name);


--
-- Name: Asset_identifier_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Asset_identifier_key" ON public."Asset" USING btree (identifier);


--
-- Name: Technique_ttpIdentifier_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Technique_ttpIdentifier_key" ON public."Technique" USING btree ("ttpIdentifier");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_resetToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_resetToken_key" ON public."User" USING btree ("resetToken");


--
-- Name: _AlertIOCs_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_AlertIOCs_B_index" ON public."_AlertIOCs" USING btree ("B");


--
-- Name: _AssetAlerts_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_AssetAlerts_B_index" ON public."_AssetAlerts" USING btree ("B");


--
-- Name: _ThreatActorTechniques_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_ThreatActorTechniques_B_index" ON public."_ThreatActorTechniques" USING btree ("B");


--
-- Name: Alert Alert_assignedInvestigatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Alert"
    ADD CONSTRAINT "Alert_assignedInvestigatorId_fkey" FOREIGN KEY ("assignedInvestigatorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Alert Alert_attackChainId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Alert"
    ADD CONSTRAINT "Alert_attackChainId_fkey" FOREIGN KEY ("attackChainId") REFERENCES public."AttackChain"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Alert Alert_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Alert"
    ADD CONSTRAINT "Alert_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."AlertCategory"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Alert Alert_techniqueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Alert"
    ADD CONSTRAINT "Alert_techniqueId_fkey" FOREIGN KEY ("techniqueId") REFERENCES public."Technique"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AssetUptime AssetUptime_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssetUptime"
    ADD CONSTRAINT "AssetUptime_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Asset Asset_assignedTeamMemberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_assignedTeamMemberId_fkey" FOREIGN KEY ("assignedTeamMemberId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Asset Asset_networkId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_networkId_fkey" FOREIGN KEY ("networkId") REFERENCES public."Network"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AttackChain AttackChain_analystId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AttackChain"
    ADD CONSTRAINT "AttackChain_analystId_fkey" FOREIGN KEY ("analystId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AttackChain AttackChain_relatedThreatActorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AttackChain"
    ADD CONSTRAINT "AttackChain_relatedThreatActorId_fkey" FOREIGN KEY ("relatedThreatActorId") REFERENCES public."ThreatActor"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Event Event_alertId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_alertId_fkey" FOREIGN KEY ("alertId") REFERENCES public."Alert"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Event Event_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Event Event_iocId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_iocId_fkey" FOREIGN KEY ("iocId") REFERENCES public."IOC"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Event Event_responseActionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_responseActionId_fkey" FOREIGN KEY ("responseActionId") REFERENCES public."ResponseAction"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Event Event_responsibleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_responsibleId_fkey" FOREIGN KEY ("responsibleId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: IOC IOC_threatActorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IOC"
    ADD CONSTRAINT "IOC_threatActorId_fkey" FOREIGN KEY ("threatActorId") REFERENCES public."ThreatActor"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Network Network_parentNetworkId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Network"
    ADD CONSTRAINT "Network_parentNetworkId_fkey" FOREIGN KEY ("parentNetworkId") REFERENCES public."Network"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ResponseAction ResponseAction_affectedAssetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResponseAction"
    ADD CONSTRAINT "ResponseAction_affectedAssetId_fkey" FOREIGN KEY ("affectedAssetId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ResponseAction ResponseAction_assignedTeamMemberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResponseAction"
    ADD CONSTRAINT "ResponseAction_assignedTeamMemberId_fkey" FOREIGN KEY ("assignedTeamMemberId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ResponseAction ResponseAction_relatedIOCId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResponseAction"
    ADD CONSTRAINT "ResponseAction_relatedIOCId_fkey" FOREIGN KEY ("relatedIOCId") REFERENCES public."IOC"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ResponseAction ResponseAction_relatedIncidentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResponseAction"
    ADD CONSTRAINT "ResponseAction_relatedIncidentId_fkey" FOREIGN KEY ("relatedIncidentId") REFERENCES public."Alert"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Technique Technique_parentTechniqueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Technique"
    ADD CONSTRAINT "Technique_parentTechniqueId_fkey" FOREIGN KEY ("parentTechniqueId") REFERENCES public."Technique"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: _AlertIOCs _AlertIOCs_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_AlertIOCs"
    ADD CONSTRAINT "_AlertIOCs_A_fkey" FOREIGN KEY ("A") REFERENCES public."Alert"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _AlertIOCs _AlertIOCs_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_AlertIOCs"
    ADD CONSTRAINT "_AlertIOCs_B_fkey" FOREIGN KEY ("B") REFERENCES public."IOC"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _AssetAlerts _AssetAlerts_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_AssetAlerts"
    ADD CONSTRAINT "_AssetAlerts_A_fkey" FOREIGN KEY ("A") REFERENCES public."Alert"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _AssetAlerts _AssetAlerts_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_AssetAlerts"
    ADD CONSTRAINT "_AssetAlerts_B_fkey" FOREIGN KEY ("B") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _ThreatActorTechniques _ThreatActorTechniques_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_ThreatActorTechniques"
    ADD CONSTRAINT "_ThreatActorTechniques_A_fkey" FOREIGN KEY ("A") REFERENCES public."Technique"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _ThreatActorTechniques _ThreatActorTechniques_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_ThreatActorTechniques"
    ADD CONSTRAINT "_ThreatActorTechniques_B_fkey" FOREIGN KEY ("B") REFERENCES public."ThreatActor"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

